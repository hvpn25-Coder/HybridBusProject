# Run without Simscape

## On the other machine

1. Copy the complete project folder, or extract the refreshed project ZIP.
2. Open `Start_RLC.m` in MATLAB and click Run.
3. Set **Simulation model** to **Basic Simulink blocks (no add-ons)**.
   This is automatically selected if Simscape functions or its license are unavailable.
4. Enter parameters and select DC, AC at 60 Hz, or pulse excitation.
5. Click **Run Simulation**, or use **Engineering comparison** for an A/B study.
6. Click **Open model** to inspect the selected block diagram.

Required: **MATLAB and Simulink**. MATLAB alone does not run a Simulink model.
The basic model needs no Simscape, Simscape Electrical, Stateflow, Control System
Toolbox, or other add-on toolbox. The delivered files were tested in R2025a; use
R2025a or a newer release. Earlier MATLAB releases need a compatible model export
and have not been validated with this GUI.

Blender is optional for simulation, plots and A/B comparison. If it is not installed,
leave **Update Blender scene** and **Render MP4** unchecked. They default to unchecked
when the prefilled Blender executable is absent. Existing MP4 files need only a video
player. To generate new animation, install Blender and update its executable path.

## Basic model implementation

`matlab/rlc_basic_model.slx` is a ready-to-run model with four subsystems:

- **VoltageSource:** Constant, Sine Wave, Pulse Generator and Multiport Switch.
- **ElectricalDynamics:** two continuous Integrators, Gains, Sums and a Product.
- **ResistorThermal:** an Integrator for temperature, with Joule heating, cooling
  to ambient and temperature-dependent resistance built from arithmetic blocks.
- **CapacitorThermal:** the same thermal structure using capacitor ESR parameters.

A Mux and To Workspace block record current, capacitor voltage, both temperatures
and the actual source voltage. There are 56 blocks including subsystem interfaces.
There are no physical-network blocks, custom libraries, MATLAB Function blocks,
S-functions or Stateflow charts in this model. The packaged `.slx` is essential;
`open_rlc_basic_model.m` locates and opens it without building any Simscape library.

The four integrated states are `i`, `vC`, `TR` and `TC`:

```
di/dt  = [Vs - (R(TR) + ESR(TC))*i - vC] / L
dvC/dt = i / C
dTR/dt = [i^2*R(TR)   - (TR-Tamb)/Rth_R] / Cth_R
dTC/dt = [i^2*ESR(TC) - (TC-Tamb)/Rth_C] / Cth_C
R(TR)   = R0   * [1 + alpha_R   * (TR-Tref)]
ESR(TC) = ESR0 * [1 + alpha_ESR * (TC-Tref)]
```

Initial current and capacitor voltage are zero. Initial temperatures equal ambient.
Temperature is internally in kelvin. The exporter derives flux, charge, fields,
energies and losses from these states using the same definitions as the physical
model. These are lumped quantities, not spatial FEM results. Both backends preserve
the same assumptions: constant L/C, no core saturation, and no winding/core loss.

## Script usage

From the project root, after adding `matlab/` to the MATLAB path:

```matlab
p = rlc_defaults();
result = run_rlc_simulation(p, fullfile(pwd,'runs','my_basic_run'), "", "basic");

b = p; b.R = 8;
study = rlc_compare_designs(p,b,fullfile(pwd,'runs','my_basic_study'),"basic");

open_rlc_basic_model();
```

Use fresh output directories. The third `run_rlc_simulation` argument is an optional
model name; an empty string selects the packaged default for the chosen backend.
Existing script calls without the fourth argument continue to use Simscape.

JSON/MAT metadata records `model_backend` as `basic` or `simscape`. The CSV field
names/order and downstream Blender interface are shared. In a basic-model MAT-file,
`out.basic_states` contains native solver samples; Simscape MAT-files use
`out.simlog_rlc` instead. Blender's footer identifies the backend for new renders.

## Validation

`verify_rlc_basic_model` checks the block inventory and compares the two backends
for DC, 60 Hz AC, a 12-second pulse simulation and changed R/L/C/ambient parameters.
Maximum observed differences across these cases were approximately 0.000125 A,
0.000638 V, and 0.000137 K. The largest normalized integral energy residual was
below 0.015%. Different solver representations and interpolation give small
numerical differences; this is equation equivalence, not hardware calibration.

`verify_rlc_without_simscape` runs in a fresh session, temporarily removes the
Simscape/physical-modeling directories from that session's search path, and checks
all three source modes and the GUI A/B route. It restores the path afterward and
checks that no Simscape license was checked out. This is a local dependency-isolation
test; it does not claim testing on the destination machine itself.

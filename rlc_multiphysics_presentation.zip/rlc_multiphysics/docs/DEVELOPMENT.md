# RLC multi-physics application plan

Basic Simulink backend: provide a separate core-block model with four integrator
states and the same electrical/thermal equations. Preserve the existing physical
network. Add a model selector and open-model action; apply selection to both run
and comparison, reuse the export schema, and default to basic when Simscape is
unavailable. Build/check through the Simulink editing tools. Validate all source
modes and changed parameters against Simscape, then isolate physmod paths in a
fresh session to test the toolbox-independent GUI route. Package both `.slx` files.

Engineering-view upgrade: preserve the existing programmatic UIFigure and modal
Simulink solve. Add a second tab with editable Design B R/L/C, an A/B comparison
action, frequency-response axes and a metric table. Both designs share source,
ambient and physical duration. Export the analytical ambient-resistance sweep
separately from actual electro-thermal transient results. Add derived power and
energy columns, verify conservation and analytical resonance, and exercise the GUI.
In Blender add an always-visible synchronized circuit schematic and a compact
energy/power strip without hiding the voltage supply. Bake all graphics into the
scene, inspect chapter stills, render and verify the complete demonstration.

ETA enhancement: retain the existing standalone UIFigure layout and external
Blender process/timer. No new background task or app restructuring is needed.
Following matlab-build-app editing-guide.md and background-tasks.md, add atomic
Blender progress snapshots and a small MATLAB status formatter. Report frame
completion, elapsed time and a measured ETA after three frames; distinguish
building, previews and video finalization. Validate with short actual renders
and MATLAB status/GUI checks, then refresh the distributable.

Architecture: standalone class-based MATLAB UIFigure app (.m), using App Designer controls.
Layout: dashboard, parameter form and actions above electrical / thermal / energy plots.
Simulation: synchronous, exclusive operation with modal progress dialog (Simulink is not
supported on backgroundPool thread workers). Blender is a separate asynchronous process;
a lightweight timer polls completion and displays failures. No Parallel Computing Toolbox.

References used: matlab-build-app references/uifigure/guide.md, grid-layout.md,
callbacks.md, references/background-tasks.md (thread compatibility and modal-operation
exception), references/archetypes/dashboard.md; building-simulink-models
references/simscape.md; simscape-write-ssc references/ports-and-nodes/branches.md.

Sequence: implement and compile physical components; build and simulate model;
validate states against independent ODE and energy balance; export SI dataset;
build deterministic data-driven Blender scene; implement and test GUI and process launch;
render demonstration and document use and limitations.

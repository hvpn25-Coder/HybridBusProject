# Management demonstration

Open `media/presentation/rlc_animation.mp4` for the supplied 26-second, 1920×1080,
24 fps demonstration. The GUI's **Open example video** opens this version.

The engineering edition adds a synchronized schematic, signed current direction,
component voltage drops, source power, stored energies, and heat generation. Use
the [engineering guide](ENGINEERING_GUIDE.md) for the signs, scales and A/B workflow.

## Suggested narration

- **0–4 s — System overview:** One series circuit couples electrical storage,
  magnetic energy and heat dissipation. The right panel reports simulation values.
  The foreground voltage supply shows its excitation type and rating, with red
  positive and blue return leads. Its waveform symbol identifies DC, AC or pulse.
- **4–10 s — Magnetic energy:** Current produces flux in the inductor. Watch the
  moving current cursor, the field pulse, and the signed flux measurement together.
- **10–16 s — Electric energy:** The capacitor charges and discharges. Arrows show
  polarity; plate glow follows voltage. This replays the same electrical interval.
- **16–22 s — Thermal response:** Resistive losses warm the resistor and capacitor
  ESR. Temperature feeds back into resistance. The color legend measures rise
  above ambient; the graph shows the resistor's temperature rise.
- **22–26 s — Results:** Peak electrical values and final temperature rises summarize
  the run. Use the MATLAB GUI to compare DC, AC at 60 Hz, or pulse excitation.

## Interpretation

This is a lumped Simscape electrical and thermal simulation. It is **not a spatial
FEM induction-heating analysis**. Streamline shapes, field colors, component geometry,
and capacitor plate separation are explanatory, not a meshed field solution or
dimensionally accurate hardware. Nine rendered coil turns symbolize the inductor;
the model's turn count is used in the flux calculation. The winding resistance and
core losses are not modeled. Capacitor heat comes from its modeled ESR.

Readouts and plots use the exported data. Field emission increases with normalized
absolute current above a small visibility floor; tracer direction reverses with
current. Tracers are visual cues, not modeled particles. Plate emission follows
absolute voltage. Thermal colors use the configured rise scale (default 0–10 K),
so a few kelvin of heating remains blue/green rather than falsely appearing molten.

The source-voltage readout uses the logged `source_V` at the displayed physical
time and remains visible in every chapter. The source output LED follows absolute
voltage. AC ratings are RMS; the live readout is instantaneous signed voltage.
The supply enclosure is omitted from electrical close-ups to keep the component
in view; it appears in the overview, thermal and summary shots. Lead polarity
labels define the reference direction; AC voltage can reverse polarity.

Every chapter labels its physical interval and playback speed. AC close-ups replay
the last two cycles; DC replays its initial transient; pulse replays the final period.
The thermal chapter covers the full simulation. `frame_mapping.csv` preserves the
exact physical time and sampled quantities for every video frame. The status JSON
records the source dataset SHA-256. The underlying full data remains in `data/default/`.

## Rebuild or customize

In MATLAB, run the project-root `Start_RLC.m`, select **Presentation | 1080p**, keep **Render MP4**
checked, and click **Run Simulation**. Wait for **Open rendered video** to enable.
This launches Blender in the background. Rendering time depends on the machine.
The **Quick | 720p** option retains the previous renderer for faster iteration.

The shell-free launcher defaults to presentation mode:

```matlab
job = launch_rlc_blender("data/default/rlc_data.json", "my_new_render", ...
    "C:\Tools\Blender\blender.exe", true, "presentation");
```

Use a fresh output directory. For custom dimensions or length, invoke
`blender/rlc_cinematic.py` through Blender's background Python CLI with `--data`,
`--output`, `--render`, `--width`, `--height`, and `--seconds` after `--`.
The saved `.blend` contains camera, material, overlay and numeric-readout keyframes;
no Python auto-run permission is needed for playback. Fonts are packed into it.

The visual direction was informed by the supplied LinkedIn reference's dark studio,
metallic coil, field overlays and measurement graphics; no reference media was copied.

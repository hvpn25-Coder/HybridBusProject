# Series RLC: MATLAB → Simulink / Simscape → Blender

This is a working, local workflow, tested with **MATLAB R2025a**, Simulink,
Simscape, and **Blender 5.2.3 LTS** on this machine. No Python packages, API keys,
Parallel Computing Toolbox, or MCP connection are required to run the delivered code.
The electrical and thermal networks use Simscape Foundation domains and custom
Simscape Language components. Simscape Electrical is installed, but its specialized
blocks are not a dependency of this particular implementation.

There are now two selectable simulation backends. **Basic Simulink blocks (no
add-ons)** uses the same lumped equations with standard Simulink blocks and needs
only MATLAB + Simulink. **Simscape physical network** additionally requires
Simscape. See [basic-model instructions](BASIC_SIMULINK.md). The custom Simscape
components below apply only to the physical-network backend.

## 1. Launch the GUI

In MATLAB:

```matlab
cd('C:\TempData\Blender_Anima_test\rlc_multiphysics')
addpath(fullfile(pwd,'matlab'))
app = RLCApp;
```

1. Enter resistance in **ohms**, inductance in **H**, capacitance in **F**, and
   ambient temperature in **°C**. Source voltage and physical simulation duration
   are also editable.
   Choose the desired **Simulation model**. The selection applies to both
   **Run Simulation** and **Run A/B comparison**; **Open model** displays it.
   Choose **DC**, **AC (60 Hz)**, or **Pulse (1 Hz)** in **Voltage source**.
   The voltage label switches to **V RMS** for AC; the sine-wave peak is
   `sqrt(2) * voltage_V`. DC is constant voltage applied at time zero. Pulse
   retains the original 50% duty waveform and remains the initial selection.
2. Leave **Update Blender scene** selected. The executable is prefilled as
   `C:\Tools\Blender\blender.exe`; change it if Blender is installed elsewhere.
3. Choose **Presentation | 1080p** (default) for the 26-second management video,
   or **Quick | 720p** for the original compact visualization. **Render MP4** is
   selected by default; clear it to build only the editable scene and preview images.
4. Click **Run Simulation**. A modal progress dialog covers the exclusive Simulink
   solve; the plots update afterward. Blender builds/renders in a separate process,
   while the app remains responsive and reports completion or a log-file location.
   The status refreshes every second with frame progress, elapsed time and ETA.
   ETA becomes available after three animation frames; it uses recent and overall
   measured frame times, so changes in scene complexity can change the estimate.
   Building/previews show “calculating”; final video encoding shows “finalizing”.
5. Each run receives a new directory under `runs/`. Open its
   `blender/rlc_animation.blend`, and press **Space** to play. Use Material Preview
   or Rendered shading to see animated materials. The MP4 needs no Blender.
6. Click **Open rendered video** in the GUI to open that run's MP4 in your default
   video player. This link is disabled during a run and for scene-only/failed runs;
   it is enabled only after Blender reports a completed render and the MP4 exists.
   On initial app launch, **Open example video** links to the supplied pulse demo.

Presentation mode replays the final two AC cycles in its electrical close-ups,
so 60 Hz remains visible even after a long simulation. DC uses the initial charging
transient; pulse mode uses the final pulse period. Each shot labels its physical
time range and playback speed. The thermal chapter covers the complete simulation.
Quick mode maps the whole simulation to 12 seconds; choose Duration = 0.1 s for AC
or heed the undersampling warning. Numerical analysis should use the MAT/CSV data.

Closing the app stops its own active Blender child process. Let rendering finish
before closing if you want the complete video. Repeated Run clicks are disabled
while a run is active. `matlab/RLCApp.m` is a standalone class using App Designer UI
components, not a binary `.mlapp` editable in Design View.

## 2. Files and responsibilities

| File | Responsibility |
|---|---|
| `build_rlc_model.m` | Reproducible MATLAB builder; creates the library/model when absent; opens existing models without overwriting |
| `matlab/rlc_multiphysics_model.slx` | Ready-to-run physical series R–L–C circuit |
| `matlab/+rlcphysics/ThermalResistor.ssc` | Temperature-dependent resistor, heat storage and ambient cooling |
| `matlab/+rlcphysics/FluxInductor.ssc` | Linear inductor, flux linkage, flux, mean B-field and energy |
| `matlab/+rlcphysics/ThermalCapacitor.ssc` | Ideal capacitance, temperature-dependent ESR, heat storage and cooling |
| `matlab/rlcphysics_lib.slx` | Compiled custom component library |
| `rlc_defaults.m` | Electrical, thermal, geometric, excitation and visualization parameters |
| `validate_rlc_parameters.m` | Input validation |
| `rlc_source_voltage.m`, `rlc_max_step.m` | DC/AC/pulse definitions and source-aware solver time-step ceiling |
| `run_rlc_simulation.m` | SimulationInput overrides, common-grid export, native Simscape logging |
| `matlab/RLCApp.m` | GUI, plots, progress/error handling and child-process monitoring |
| `launch_rlc_blender.m` | Shell-free, asynchronous MATLAB-to-Blender process launcher |
| `blender/rlc_cinematic.py` | 1080p chaptered presentation, camera animation, studio materials, plots and baked telemetry |
| `blender/rlc_visualize.py` | Data parser, scene creation, material/transform keyframes, preview and optional MP4 rendering |
| `verify_rlc_workflow.m` | Independent ODE, conservation, zero-source and parameter-update checks |
| `verify_rlc_sources.m` | Applied waveform checks for all modes; AC RMS and impedance-response verification |
| `data/default/` | Default 12-second simulation MAT, CSV and JSON |
| `media/quick/` | Completed 12-second example Blender scene, preview and MP4 |
| `media/presentation/` | New 26-second 1080p video, editable scene, chapter stills and frame mapping |
| `PRESENTATION.md` | Presenter narration, timing, rendering options and interpretation |
| `verification/report.json` | Numerical validation results |

The builder uses standard MATLAB/Simulink APIs; the delivered project is independent
of agent tools. To prove regeneration without disturbing the supplied model:

```matlab
build_rlc_model("my_rlc_copy")
result = run_rlc_simulation(rlc_defaults(),fullfile(pwd,'my_data'),"my_rlc_copy");
```

If you edit `.ssc` files, close the generated library and rebuild it with:

```matlab
if bdIsLoaded('rlcphysics_lib'), close_system('rlcphysics_lib',0); end
cd(fullfile(rlc_project_root(),'matlab')); sscbuild('rlcphysics')       % R2024b onward; older releases use ssc_build
```

## 3. Physical model and assumptions

Topology: controlled voltage source → temperature-dependent resistor → linear
inductor → capacitor with series ESR → source return. Both thermal ports exchange
heat with a shared ideal constant-temperature ambient boundary. Component thermal
storage and thermal resistance are inside their `.ssc` definitions, rather than
separate Thermal Mass blocks. The ambient Temperature Source is an absolute,
one-port source, so no extra Thermal Reference is required.

With `TR`, `TC`, and `Tamb` in kelvin:

```text
R(TR)     = R0 [1 + alpha_R   (TR - Tref)]
ESR(TC)   = ESR0 [1 + alpha_ESR (TC - Tref)]
L di/dt   = Vs - (R(TR) + ESR(TC)) i - vC
C dvC/dt  = i
Cth_R dTR/dt = i² R(TR)   - (TR - Tamb)/Rth_R
Cth_C dTC/dt = i² ESR(TC) - (TC - Tamb)/Rth_C
lambda = L i;  Phi = lambda/N;  B = Phi/Acore
q = C vC;      E = vC/gap
Wmag = L i²/2; Welec = C vC²/2
```

- `R` in the GUI is specified at **25°C**, not at the entered ambient temperature.
  The initial resistance changes correctly when ambient differs from that reference.
- Initial current and dielectric voltage are zero; both components start at ambient.
- Capacitor heating is **ESR dissipation**. An ideal capacitance alone does not heat.
  `v_C_V` is the dielectric voltage; `v_C_terminal_V` additionally includes `i*ESR`.
- Capacitance and inductance are constant. No capacitor leakage, dielectric relaxation,
  core saturation/hysteresis, inductor winding loss, radiation or spatial temperature
  gradients are modeled. ESR's positive temperature coefficient is a configurable
  illustrative choice, not a universal capacitor material law.
- `Phi` is flux per turn; `lambda` is flux linkage. They are not interchangeable.
  Turns are dimensionless in the Simscape unit system; linkage is labeled Wb-turn
  in the export to distinguish it from flux.
- `B` and `E` are **lumped mean estimates**, not a magnetic/electrostatic FEM solution.
  `N`, `Acore`, and `gap` must match the physical component if quantitative fields
  matter. Specifying `C` and `gap` implicitly leaves dielectric permittivity and area
  unspecified. Blender plate sizes/visible coil turns are illustrative.
- Default geometry: 200 effective turns, 0.004 m² core area, 0.002 m dielectric gap.
  The linear model does not automatically enforce a material's saturation limit.

The default pulse source is 0↔24 V, 1 s period, 50% duty. Repeated charging/discharging
makes both fields and accumulated heating visible. Set `p.duty_pct=100` for a DC
step in pulse mode, or choose the explicit `p.source_mode=1` DC mode.
Set `p.source_mode=2` for AC, with `p.frequency_Hz=60` and `p.voltage_V` in RMS volts.
`p.source_mode=3` selects pulse mode. Edit `rlc_defaults.m` or the parameter struct for thermal
constants, geometry, source period, color scale, or animation length.

## 4. Run without the GUI

```matlab
p = rlc_defaults();
p.R = 5; p.L = 0.15; p.C = 0.004; p.Tamb_C = 30;
p.source_mode = 2; p.frequency_Hz = 60; % 1=DC, 2=AC, 3=pulse
p.stop_s = 0.1;                        % slow-motion view of six AC cycles
result = run_rlc_simulation(p,fullfile(pwd,'experiment_01'));
job = launch_rlc_blender(result.json,fullfile(pwd,'experiment_01','blender'), ...
    "C:\Tools\Blender\blender.exe",true);
% Asynchronous: MATLAB is immediately available again.
% job.process.isAlive() indicates whether the child is running.
% When it exits, inspect job.process.exitValue(), job.status and job.log.
```

Use a fresh Blender output directory for each launch. A completed status file is
rejected by the launcher to prevent accidentally reporting a stale run as successful.
The simulation function overwrites its named MAT/JSON/CSV outputs if its output
directory is reused; the GUI always creates a unique run directory.

The Java ProcessBuilder passes executable and arguments separately, so paths with
spaces are handled without PowerShell/cmd quoting or shell interpolation.

Equivalent standalone PowerShell command:

```powershell
& 'C:\Tools\Blender\blender.exe' --background --python-exit-code 1 `
  --python 'C:\TempData\Blender_Anima_test\rlc_multiphysics\blender\rlc_cinematic.py' -- `
  --data 'C:\TempData\Blender_Anima_test\rlc_multiphysics\data\default\rlc_data.json' `
  --output 'C:\TempData\Blender_Anima_test\rlc_multiphysics\manual_render' --render
```

Omit `--render` to save the keyframed `.blend` and chapter PNG previews only. Optional
`--width 1920 --height 1080` changes render resolution. The saved `.blend` already
contains all keyframes and H.264/MPEG-4 settings, so it can also be rendered with
`blender --background rlc_animation.blend --render-anim`.

## 5. Data contract and visualization mapping

`rlc_results.mat` contains `out` (native Simscape log and solver times), `d` (common
grid table), `p`, and `meta`. CSV contains the same numerical table. JSON contains
`metadata` and `data`, whose named fields are numeric arrays. The Blender script
reads **JSON**, which includes units/normalization and timing metadata; CSV is supplied
for analysis and interchange. Neither exporter nor Blender parser executes data as code.

| Column | Unit / meaning |
|---|---|
| `time_s` | physical seconds |
| `i_L_A` | series/inductor current, A |
| `v_C_V`, `v_C_terminal_V` | dielectric and terminal voltage, V |
| `flux_linkage_Wb_turn`, `Phi_Wb`, `B_T` | linkage, flux per turn, mean field |
| `charge_C`, `E_V_per_m` | capacitor charge and dielectric field |
| `T_R_K`, `T_C_K`, `T_amb_K` | absolute temperature, K |
| `R_ohm`, `ESR_ohm` | temperature-adjusted resistances |
| `P_R_W`, `P_C_W` | irreversible heat production |
| `W_magnetic_J`, `W_electric_J` | stored field energy |
| `source_V` | right-continuous commanded source voltage |

Presentation mode uses chapter-specific replay windows, a fixed 0–10 K thermal
palette, and baked numeric telemetry. See [PRESENTATION.md](PRESENTATION.md) for
its exact visual mappings, physical scope and suggested narration. It produces
1920×1080 at 24 fps for 26 seconds, independently of physical simulation duration.

Legacy **Quick | 720p** mappings:

- Electrode/gap emission is proportional to `abs(vC)` (equivalently `abs(E)` for
  fixed gap); negative voltage changes emission hue. Brightness saturates at twice
  the normalization voltage to keep images readable.
- Coil field-line emission and tracer size reflect `abs(i)` (equivalently flux
  for constant L/N); signed current controls the tracer travel direction/speed.
  Tracers represent illustrative field activity, **not electron drift or literal
  particles moving along magnetic field lines**.
- Resistor body and capacitor base colors interpolate from blue at ambient to
  orange at `ambient + 10 K`, configurable by `temperature_span_K`. The same fixed
  scale is used across runs; it is not autoscaled to exaggerate tiny heating.
- The source sphere follows source voltage; a cursor advances along the time rail.
- All source data are linearly sampled at animation-frame times. Physical `[0,stop_s]`
  maps to `[1,round(fps*animation_seconds)]`. Default: 12 physical seconds, 12 video
  seconds, 24 fps, 1280×720. Altering the animation duration changes playback speed,
  not circuit physics. Last-frame sampling and nominal encoded duration differ by
  one frame interval in the usual endpoint-inclusive convention.

In Quick mode, fast oscillations can alias in a low-frame-rate video. The app warns if visual
sampling falls below ten times the undamped natural frequency. Increase FPS or
`animation_seconds` for slow motion; always use the MAT/CSV for numerical analysis.
The model uses an adaptive stiff solver with a time-step ceiling tied to LC and
source period. Extreme parameter combinations can be expensive and may require
additional solver/tolerance tuning.

## 6. Verification

```matlab
report = verify_rlc_workflow();
sourceReport = verify_rlc_sources();
```

Checks include an independently integrated four-state ODE with exact pulse edge
intervals, integral energy conservation (including stored heat and ambient cooling),
zero-input equilibrium, state/field identities, and R/L/C/ambient parameter changes.
Native state targets and SI units are checked by Simscape compilation.

Observed default test results:

- Maximum current disagreement: about 0.000114 A.
- Maximum capacitor-voltage disagreement: about 0.000650 V.
- Maximum normalized energy-balance residual: about **0.0153%**.
- Final resistor rise: **3.624 K**; capacitor rise: **0.781 K**.

These validate implementation consistency; they do not calibrate the illustrative
component parameters against physical hardware. See `verification/report.json` for
machine-readable measured values.

The source-mode checks additionally verify the voltage actually imposed by the
Simscape source, a 24 V RMS / 60 Hz sine, DC settling to 24 V, and steady-state
AC current against the series impedance. Results are in `verification/source_report.json`.

## 7. Troubleshooting

- Missing custom blocks: add this project root to MATLAB's path and run
  `cd(fullfile(rlc_project_root(),'matlab')); sscbuild('rlcphysics')`; keep the `+rlcphysics` folder with the project.
- The builder opens an existing model without replacing it. Rename the model or
  call it with a new model name if you want a freshly generated topology.
- Blender failure: inspect the run's `blender.log` and `blender_status.json`.
- No color changes in Blender: switch Solid shading to Material Preview/Rendered.
- No thermal rise on a one-time step after charging: expected; the series current
  decays to zero, so heating stops and cooling dominates. Use repeated pulses.
- Long simulation: choose electrical values/time span suited to your analysis.
  Simulink simulation is intentionally modal; only Blender runs asynchronously.

The previous rolling-ball files elsewhere in the parent workspace are unrelated
and are preserved.

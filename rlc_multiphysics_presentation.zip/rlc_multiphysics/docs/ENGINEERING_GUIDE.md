# Engineering views and design comparison

## Run a comparison

1. Run the project-root `Start_RLC.m` in MATLAB.
2. Set **Design A** using the main resistance, inductance, capacitance, ambient,
   source voltage, source type and duration controls.
3. Open **Engineering comparison**. Enter Design B's R, L and C.
4. Click **Run A/B comparison**. Both designs run through the selected simulation model,
   with identical source excitation, ambient, duration and other default parameters.
   Blender is not required for this comparison.
   Select **Basic Simulink blocks (no add-ons)** when Simscape is not installed.
5. Inspect **Frequency response** and **Transients and heating**. The table shows
   both values and the signed difference **B minus A**. Positive is not inherently
   better or worse; interpret each metric against the design objective.
6. Use **Open comparison results** for CSV/JSON reports, a dashboard image and each
   design's full simulation MAT/CSV/JSON dataset. Each comparison gets a fresh run folder.

The supplied example is in `data/comparison_example/`. It compares 4 ohm and 8 ohm
resistors with L = 0.2 H, C = 0.005 F, 24 V pulse excitation, 25 C ambient and a
12-second physical duration.

| Result | Design A: 4 ohm | Design B: 8 ohm |
|---|---:|---:|
| Peak current | 2.430 A | 1.798 A |
| Peak ideal-capacitor voltage | 31.591 V | 25.514 V |
| Final resistor rise | 3.624 K | 3.763 K |
| Final capacitor rise | 0.781 K | 0.405 K |
| Heat generated in R + ESR | 34.661 J | 34.561 J |
| LC resonance | 5.033 Hz | 5.033 Hz |
| Series quality factor at ambient | 1.454 | 0.757 |

Increasing R reduces overshoot and current in this example, but does not reduce
every temperature. It redistributes the losses: the resistor warms slightly more
and the capacitor ESR warms less. These are illustrative model results, not measured
hardware ratings or an automatically optimized design.

## Frequency-sweep assumptions

The sweep is an analytical sinusoidal response, not a thermal steady-state sweep.
Its RMS excitation is the absolute value of the main source-voltage input, even
when the selected transient source is DC or pulse. R and ESR are frozen at the
entered ambient temperature. Inductance and capacitance remain constant.

```
Z(f) = R(Tamb) + ESR(Tamb) + j [2*pi*f*L - 1/(2*pi*f*C)]
Irms = Vrms / |Z|             phase(I relative to Vs) = -angle(Z)
f0 = 1/(2*pi*sqrt(L*C))       Q = sqrt(L/C)/(R + ESR)
zeta = 1/(2*Q)
```

The sweep spans two decades below and above the two LC resonances and 60 Hz;
the exact resonance frequencies and 60 Hz are included in its sample grid.
Its phase plot is the linear transfer-function phase. At zero excitation the
current is zero, while the displayed transfer-function phase is still defined.
The transient/heating plots and peak/thermal table entries come from actual
electro-thermal runs in the selected backend, with temperature-dependent resistance enabled.

## Synchronized presentation graphics

The 1080p presentation includes a series schematic above the 3D components. It
shows the ideal capacitor and its ESR separately. The arrow follows signed current;
the voltages use a fixed left-to-right drop reference. Negative current or voltage
does not change that reference. Inductor voltage is derived by KVL from the logged
source, resistor, ESR and ideal-capacitor voltages; it is not a new independent sensor.

The bottom strip shows:

- **Source power (W):** positive when the ideal source delivers power; negative
  when the circuit returns power. The model's ideal source can absorb energy.
- **Magnetic and electric energy (J):** instantaneous storage in L and C.
- **Heat rate (W):** instantaneous R and capacitor-ESR dissipation.
- **Heat generated (J):** integrated dissipation since physical time zero.

Heat generated is not the same as heat still stored in the components: some has
already passed to ambient. The magnitude bars each use their own full-run scale;
compare numerical values and units rather than bar lengths across different fields.
All overlays follow the displayed physical clock, including deliberate chapter
replays. They remain baked in the `.blend`, with no Python auto-run needed to play.

## Numerical checks and scope

`verify_rlc_engineering` checks the resonance amplitude/phase, ambient-temperature
effect, both GUI-driven simulations, monotonic dissipated energy, KVL, and energy
conservation. The example's normalized integral energy residual is below 0.016%.
Small instantaneous power discrepancies arise because logged powers and states
are independently interpolated onto the export time grid.

New simulation exports contain component voltage drops, source/storage/heat powers,
net source energy, cumulative heat, total electrical storage and an energy-balance
residual. The original reference data remains compatible with the animation.

This upgrade adds engineering interpretation and comparisons. It does not add
spatial FEM, measured calibration, inductor winding/core loss, saturation, or a
component safety rating model. Those require additional physical parameters and
validation before claiming hardware accuracy.

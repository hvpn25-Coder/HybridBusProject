%START_RLC Open the RLC simulation and animation GUI from this project folder.
projectFolder = fileparts(mfilename('fullpath'));
addpath(fullfile(projectFolder,'matlab'));
app = RLCApp;

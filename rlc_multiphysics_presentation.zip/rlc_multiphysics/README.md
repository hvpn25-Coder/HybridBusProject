# RLC simulation and animation

**Start here:** open `Start_RLC.m` in MATLAB and click **Run**.
The GUI includes AC 60 Hz, DC and pulse excitation, rendering quality selection,
and a link to the finished video.

**Without Simscape:** choose **Simulation model → Basic Simulink blocks (no add-ons)**.
This requires MATLAB and Simulink only. It supports all source types, thermal
feedback, A/B comparison, exports and Blender visualization. The GUI selects this
mode automatically when Simscape is unavailable. **Open model** shows the selected
model. See [portable-model instructions](docs/BASIC_SIMULINK.md).

Blender is required only to create new 3D scenes/videos. If its default executable
is absent, the GUI starts with Blender generation and rendering unchecked.

While rendering, the GUI shows completed frames, percentage, elapsed time and an
estimated time remaining. The ETA starts after three rendered frames and adjusts
to measured rendering speed. Scene building and previews show “ETA: calculating”.

**Watch the presentation:** [26-second Full HD video](media/presentation/rlc_animation.mp4).
The presentation includes a labeled voltage supply with DC/AC/pulse identification,
separate positive and return leads, and a live source-voltage readout.
It also includes a synchronized circuit schematic and a signed power/energy strip.

**Compare designs:** open the GUI's **Engineering comparison** tab, enter Design B's
R/L/C and click **Run A/B comparison**. Explore resonance, phase, transient current,
temperature and numerical differences. See [engineering guide](docs/ENGINEERING_GUIDE.md).

| Folder | Contents |
|---|---|
| `matlab/` | GUI, simulation functions, Simulink models and `+rlcphysics` components |
| `blender/` | Animation, verification and packaging Python scripts |
| `data/default/` | Reference simulation data: JSON, CSV and MAT |
| `data/comparison_example/` | Validated A/B study, sweeps, reports and both simulation datasets |
| `media/presentation/` | Final 1080p video, editable Blender scene and chapter stills |
| `media/quick/` | Original 720p example video and scene |
| `docs/` | Integration guide, presenter notes and GUI screenshots |
| `runs/` | New simulations and renders created by the GUI |
| `verification/` | Validation reports; future verification runs also write here |
| `cache/` | Regenerable Simulink compilation files |
| `archive/cleanup_2026-11-01/` | Earlier runs, experiments, logs and caches, preserved for reference |

For command-line MATLAB use:

```matlab
cd('C:\TempData\Blender_Anima_test\rlc_multiphysics')
addpath(fullfile(pwd,'matlab'))
app = RLCApp;
```

See [integration instructions](docs/INTEGRATION.md) and
[presenter notes](docs/PRESENTATION.md).

The cleanup archive includes a `move_manifest.json` recording every move. No
existing project files were deleted. Archived paths and logs describe historical
runs; use the current folders above for new work. The packaging script excludes
archives, caches and run history from the distributable ZIP.

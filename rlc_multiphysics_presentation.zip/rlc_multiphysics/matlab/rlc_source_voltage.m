function v = rlc_source_voltage(t,p)
%RLC_SOURCE_VOLTAGE Modes: 1=DC, 2=sinusoidal AC (voltage_V is RMS), 3=pulse.
switch p.source_mode
    case 1
        v=p.voltage_V*ones(size(t));
    case 2
        v=sqrt(2)*p.voltage_V*sin(2*pi*p.frequency_Hz*t);
    case 3
        v=p.voltage_V*double(mod(t,p.period_s)<p.period_s*p.duty_pct/100);
    otherwise
        error('RLC:Source','Unknown source mode.');
end
end

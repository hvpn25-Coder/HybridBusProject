function lines = rlc_blender_progress_text(progressFile, elapsedSeconds)
%RLC_BLENDER_PROGRESS_TEXT Read advisory progress without interrupting the GUI.
lines={'Blender: building scene | ETA: calculating...', ...
    ['Elapsed: ' durationText(elapsedSeconds)]};
if ~isfile(progressFile), return; end
try
    p=jsondecode(fileread(progressFile));
    switch p.phase
        case 'previews'
            lines{1}=sprintf('Blender: rendering previews (%d/%d) | ETA: calculating...',p.completed,p.total);
        case 'rendering'
            percentage=min(100,100*p.completed/max(p.total,1));
            estimate='calculating (first few frames)...';
            if p.completed>=p.total
                estimate='finalizing video...';
            elseif isfield(p,'eta_seconds') && ~isempty(p.eta_seconds) && isfinite(p.eta_seconds)
                estimate=['about ' durationText(p.eta_seconds) ' remaining'];
            end
            lines{1}=sprintf('Blender: rendering frame %d/%d (%.0f%%) | ETA: %s', ...
                p.completed,p.total,percentage,estimate);
            lines{2}=[lines{2} ' | Estimate adjusts to measured frame times.'];
        case 'finalizing'
            lines{1}='Blender: finalizing video and saving results...';
    end
catch
    % A missing/incomplete advisory snapshot must not stop the polling timer.
end
end

function text=durationText(seconds)
seconds=max(0,ceil(seconds));
if seconds>=3600
    text=sprintf('%dh %02dm %02ds',floor(seconds/3600),floor(mod(seconds,3600)/60),mod(seconds,60));
else
    text=sprintf('%dm %02ds',floor(seconds/60),mod(seconds,60));
end
end

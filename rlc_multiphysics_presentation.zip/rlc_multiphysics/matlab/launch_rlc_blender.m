function job = launch_rlc_blender(jsonPath, outputDir, blenderExe, renderVideo, style)
%LAUNCH_RLC_BLENDER Start Blender without a shell; paths are separate arguments.
arguments
    jsonPath (1,1) string
    outputDir (1,1) string
    blenderExe (1,1) string = "C:\Tools\Blender\blender.exe"
    renderVideo (1,1) logical = false
    style (1,1) string {mustBeMember(style,["presentation","quick"])} = "presentation"
end
assert(isfile(blenderExe),'RLC:Blender','Blender executable not found: %s',blenderExe);
assert(isfile(jsonPath),'RLC:Data','Dataset not found: %s',jsonPath);
if ~isfolder(outputDir), mkdir(outputDir); end
[~,a]=fileattrib(jsonPath); jsonPath=string(a.Name);
[~,a]=fileattrib(outputDir); outputDir=string(a.Name);
[~,a]=fileattrib(blenderExe); blenderExe=string(a.Name);
script=fullfile(rlc_project_root(),'blender','rlc_visualize.py');
if style=="presentation"
    script=fullfile(rlc_project_root(),'blender','rlc_cinematic.py');
end
% Each GUI run uses a fresh directory, avoiding stale completion markers.
statusFile=fullfile(outputDir,'blender_status.json');
assert(~isfile(statusFile),'RLC:ExistingRun','Choose a fresh output folder for Blender.');
args=java.util.ArrayList;
values=[blenderExe,"--background","--python-exit-code","1","--python",string(script),"--", ...
    "--data",jsonPath,"--output",outputDir];
if renderVideo, values(end+1)="--render"; end
for value=values, args.add(java.lang.String(char(value))); end
builder=java.lang.ProcessBuilder(args);
builder.redirectErrorStream(true);
logfile=fullfile(outputDir,'blender.log');
builder.redirectOutput(java.io.File(char(logfile)));
process=builder.start();
job=struct('process',process,'log',logfile,'status',statusFile,'outputDir',outputDir, ...
    'progress',fullfile(outputDir,'blender_progress.json'),'started',tic);
end

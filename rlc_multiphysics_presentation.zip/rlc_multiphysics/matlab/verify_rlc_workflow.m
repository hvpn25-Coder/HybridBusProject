function report = verify_rlc_workflow()
%VERIFY_RLC_WORKFLOW Independent ODE, energy, zero-input and parameter tests.
root=rlc_project_root();
p=rlc_defaults();
r=run_rlc_simulation(p,fullfile(root,'verification','default'));
d=r.data; t=d.time_s;
% Integrate separately over pulse intervals so discontinuities are exact.
edges=unique([0:p.period_s:p.stop_s, ...
    p.period_s*p.duty_pct/100:p.period_s:p.stop_s,p.stop_s]);
y0=[0;0;p.Tamb_C+273.15;p.Tamb_C+273.15];
ref=zeros(numel(t),4);
opts=odeset('RelTol',1e-9,'AbsTol',1e-10,'MaxStep',0.001);
for k=1:numel(edges)-1
    a=edges(k); b=edges(k+1);
    source=p.voltage_V*double(mod((a+b)/2,p.period_s)<p.period_s*p.duty_pct/100);
    sol=ode15s(@(~,y)rhs(y,source,p),[a b],y0,opts);
    ix=t>=a & t<=b;
    ref(ix,:)=deval(sol,t(ix))';
    y0=sol.y(:,end);
end
observed=[d.i_L_A,d.v_C_V,d.T_R_K,d.T_C_K];
absError=max(abs(observed-ref),[],1);
scales=[max(abs(ref(:,1))),max(abs(ref(:,2))),1,1];
normalized=absError./max(scales,1);
assert(all(normalized<2e-3),'RLC:Reference','Independent ODE disagreement: %s',mat2str(normalized));
% Integral energy conservation: electrical input = stored electrical/magnetic
% energy + stored sensible heat + heat rejected to the ambient boundary.
input=cumtrapz(t,d.source_V.*d.i_L_A);
thermal=p.Cth_R*(d.T_R_K-d.T_amb_K)+p.Cth_C*(d.T_C_K-d.T_amb_K);
rejected=cumtrapz(t,(d.T_R_K-d.T_amb_K)/p.Rth_R+(d.T_C_K-d.T_amb_K)/p.Rth_C);
residual=input-d.W_magnetic_J-d.W_electric_J-thermal-rejected;
energyError=max(abs(residual))/max(max(abs(input)),1);
assert(energyError<0.01,'RLC:Energy','Energy error exceeds 1%%: %.4g',energyError);
assert(max(abs(d.flux_linkage_Wb_turn-p.L*d.i_L_A))<1e-8);
assert(max(abs(d.Phi_Wb-p.L*d.i_L_A/p.turns))<1e-8);
assert(max(abs(d.charge_C-p.C*d.v_C_V))<1e-8);
assert(max(abs(d.E_V_per_m-d.v_C_V/p.gap_m))<1e-5);
assert(min(d.T_R_K-d.T_amb_K)>-1e-6 && min(d.T_C_K-d.T_amb_K)>-1e-6);
q=p; q.voltage_V=0; q.stop_s=1;
zero=run_rlc_simulation(q,fullfile(root,'verification','zero'));
assert(max(abs(zero.data.i_L_A))<1e-9 && max(abs(zero.data.v_C_V))<1e-9);
assert(max(abs(zero.data.T_R_K-zero.data.T_amb_K))<1e-7);
assert(max(abs(zero.data.T_C_K-zero.data.T_amb_K))<1e-7);
q=p; q.R=6; q.L=0.3; q.C=0.003; q.Tamb_C=40; q.stop_s=1;
changed=run_rlc_simulation(q,fullfile(root,'verification','changed'));
assert(abs(changed.data.R_ohm(1)-q.R*(1+q.alpha_R*(q.Tamb_C+273.15-q.Tref_K)))<1e-8);
assert(max(abs(changed.data.Phi_Wb-q.L*changed.data.i_L_A/q.turns))<1e-8);
assert(max(abs(changed.data.charge_C-q.C*changed.data.v_C_V))<1e-8);
assert(abs(changed.data.T_R_K(1)-(q.Tamb_C+273.15))<1e-8);
report=struct('passed',true,'max_absolute_state_error',absError, ...
    'state_order',{{'i_A','vC_V','TR_K','TC_K'}}, ...
    'normalized_energy_error',energyError,'zero_input_passed',true, ...
    'parameter_update_passed',true,'final_temperature_rise_K', ...
    [d.T_R_K(end)-d.T_amb_K(end),d.T_C_K(end)-d.T_amb_K(end)]);
fid=fopen(fullfile(root,'verification','report.json'),'w');
closer=onCleanup(@()fclose(fid)); fprintf(fid,'%s',jsonencode(report,PrettyPrint=true));
disp(report);
end

function dy=rhs(y,source,p)
r=p.R*(1+p.alpha_R*(y(3)-p.Tref_K));
esr=p.ESR*(1+p.alpha_ESR*(y(4)-p.Tref_K));
ambient=p.Tamb_C+273.15;
dy=[(source-y(2)-(r+esr)*y(1))/p.L; y(1)/p.C; ...
    (y(1)^2*r-(y(3)-ambient)/p.Rth_R)/p.Cth_R; ...
    (y(1)^2*esr-(y(4)-ambient)/p.Rth_C)/p.Cth_C];
end

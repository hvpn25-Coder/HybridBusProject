function d=rlc_energy_accounting(d)
%RLC_ENERGY_ACCOUNTING Passive voltage drops and electrical energy accounting.
% Positive source power enters the circuit; negative power returns to the source.
d.v_R_V=d.i_L_A.*d.R_ohm;
d.v_ESR_V=d.i_L_A.*d.ESR_ohm;
d.v_L_V=d.source_V-d.v_R_V-d.v_ESR_V-d.v_C_V;
d.P_source_W=d.source_V.*d.i_L_A;
d.P_inductor_W=d.v_L_V.*d.i_L_A;
d.P_capacitor_W=d.v_C_V.*d.i_L_A;
d.P_heat_W=d.P_R_W+d.P_C_W;
d.E_source_net_J=cumtrapz(d.time_s,d.P_source_W);
d.E_heat_J=cumtrapz(d.time_s,d.P_heat_W);
d.E_stored_J=d.W_magnetic_J+d.W_electric_J;
d.E_balance_error_J=d.E_source_net_J-(d.E_stored_J-d.E_stored_J(1))-d.E_heat_J;
end

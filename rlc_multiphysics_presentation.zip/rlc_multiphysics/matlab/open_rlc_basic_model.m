function model=open_rlc_basic_model(model)
%OPEN_RLC_BASIC_MODEL Open the packaged model made only from basic Simulink blocks.
arguments
    model (1,1) string = "rlc_basic_model"
end
assert(isvarname(model),'RLC:ModelName','Use a valid MATLAB model name.');
folder=fileparts(mfilename('fullpath')); addpath(folder);
file=fullfile(folder,model+'.slx');
assert(isfile(file),'RLC:BasicModelMissing', ...
    'Basic Simulink model missing: %s. Copy the complete project, including matlab/rlc_basic_model.slx.',file);
if ~bdIsLoaded(model), open_system(file); end
end

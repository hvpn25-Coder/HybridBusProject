function verify_rlc_progress()
%VERIFY_RLC_PROGRESS Check user-visible ETA states and GUI construction.
folder=fullfile(rlc_project_root(),'verification','eta_check');
if ~isfolder(folder), mkdir(folder); end
file=fullfile(folder,'formatter_fixture.json');
lines=rlc_blender_progress_text(fullfile(folder,'missing.json'),5);
assert(contains(lines{1},'calculating'));
p=struct('phase','rendering','completed',100,'total',624,'eta_seconds',125);
writeFixture(p);
lines=rlc_blender_progress_text(file,85);
assert(contains(lines{1},'100/624 (16%)'));
assert(contains(lines{1},'2m 05s remaining'));
assert(contains(lines{2},'1m 25s'));
p.completed=1; p.eta_seconds=[]; writeFixture(p);
lines=rlc_blender_progress_text(file,3);
assert(contains(lines{1},'first few frames'));
p.phase='finalizing'; writeFixture(p);
lines=rlc_blender_progress_text(file,200);
assert(contains(lines{1},'finalizing'));
fid=fopen(file,'w'); fprintf(fid,'{broken'); fclose(fid);
lines=rlc_blender_progress_text(file,3);
assert(contains(lines{1},'calculating'));
app=RLCApp; cleanup=onCleanup(@()delete(app));
assert(isfile(app.VideoPath));
p=struct('phase','rendering','completed',100,'total',624,'eta_seconds',125);
writeFixture(p);
app.Status.Value=rlc_blender_progress_text(file,85);
drawnow;
exportapp(app.UIFigure,fullfile(folder,'gui_eta.png'));
disp('ETA_FORMATTER_AND_GUI_PASS');
    function writeFixture(value)
        fid=fopen(file,'w'); closer=onCleanup(@()fclose(fid));
        fprintf(fid,'%s',jsonencode(value));
    end
end

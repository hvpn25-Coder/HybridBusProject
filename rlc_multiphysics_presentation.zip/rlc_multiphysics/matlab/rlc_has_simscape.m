function available=rlc_has_simscape()
%RLC_HAS_SIMSCAPE Check availability without checking out a Simscape license.
available=(~isempty(which('sscbuild')) || ~isempty(which('ssc_build'))) ...
    && license('test','Simscape');
end

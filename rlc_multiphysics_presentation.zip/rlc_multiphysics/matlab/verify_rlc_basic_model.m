function verify_rlc_basic_model()
%VERIFY_RLC_BASIC_MODEL Cross-check the basic-block implementation against Simscape.
root=rlc_project_root(); folder=fullfile(root,'verification','basic_simulink');
if ~isfolder(folder), mkdir(folder); end
model=open_rlc_basic_model();
blocks=find_system(model,'Type','Block');
types=get_param(blocks,'BlockType');
allowed={'SubSystem','Inport','Outport','Constant','Sin','DiscretePulseGenerator', ...
    'MultiPortSwitch','Gain','Integrator','Sum','Product','Bias','Mux','ToWorkspace'};
assert(all(ismember(types,allowed)),'Model contains a non-basic block.');
references=get_param(blocks,'ReferenceBlock');
assert(all(cellfun(@(s)isempty(s)||startsWith(s,'simulink/'),references)));
cases=cell(1,4);
for mode=1:3
    p=rlc_defaults(); p.source_mode=mode;
    if mode==1, p.stop_s=2; elseif mode==2, p.stop_s=.25; end
    cases{mode}=p;
end
p=rlc_defaults(); p.R=6; p.L=.1; p.C=.002; p.Tamb_C=45; p.stop_s=2;
cases{4}=p;
errors=zeros(4,4); energyResidual=zeros(1,4);
for k=1:4
    p=cases{k};
    a=run_rlc_simulation(p,fullfile(folder,sprintf('case_%d_basic',k)),"","basic");
    b=run_rlc_simulation(p,fullfile(folder,sprintf('case_%d_simscape',k)),"","simscape");
    assert(isequal(a.data.Properties.VariableNames,b.data.Properties.VariableNames));
    columns={'i_L_A','v_C_V','T_R_K','T_C_K'};
    for j=1:4, errors(k,j)=max(abs(a.data.(columns{j})-b.data.(columns{j}))); end
    assert(all(errors(k,:)<[.003,.02,.003,.003]),'Basic/Simscape agreement failed.');
    energyResidual(k)=max(abs(a.data.E_balance_error_J))/max(1,max(abs(a.data.E_source_net_J)));
    assert(energyResidual(k)<.003,'Basic energy balance exceeds 0.3 percent.');
    native=load(fullfile(a.outputDir,'rlc_results.mat'),'out');
    raw=native.out.basic_states;
    states=reshape(raw.Data,numel(raw.Time),[]);
    % At pulse edges different solver event samples may represent either side.
    keep=true(size(raw.Time));
    if p.source_mode==3
        phase=mod(raw.Time,p.period_s);
        keep=phase>1e-7 & abs(phase-p.period_s*p.duty_pct/100)>1e-7;
    end
    expected=rlc_source_voltage(raw.Time,p);
    assert(max(abs(states(keep,5)-expected(keep)))<1e-8,'Actual basic source waveform mismatch.');
end
zero=rlc_defaults(); zero.voltage_V=0; zero.Tamb_C=40; zero.stop_s=.1;
z=run_rlc_simulation(zero,fullfile(folder,'zero_basic'),"","basic");
assert(max(abs(z.data.i_L_A))<1e-10 && max(abs(z.data.v_C_V))<1e-10);
assert(max(abs(z.data.T_R_K-(zero.Tamb_C+273.15)))<1e-9);
report=struct('passed',true,'block_count',numel(blocks),'block_types',{unique(types)}, ...
    'comparison_columns',{columns},'maximum_absolute_errors',errors, ...
    'normalized_energy_residual',energyResidual,'cases',{{'DC','AC60Hz','Pulse12s','ChangedRLCAndAmbient'}});
fid=fopen(fullfile(folder,'cross_backend_report.json'),'w'); fprintf(fid,'%s',jsonencode(report)); fclose(fid);
disp(report); disp('BASIC_VS_SIMSCAPE_PASS');
end

function validate_rlc_parameters(p)
%VALIDATE_RLC_PARAMETERS Reject incomplete, nonfinite or nonphysical inputs.
arguments
    p (1,1) struct
end
defaults=rlc_defaults(); names=fieldnames(defaults);
for k=1:numel(names)
    assert(isfield(p,names{k}),'RLC:MissingParameter','Missing %s.',names{k});
    validateattributes(p.(names{k}),{'numeric'},{'real','finite','scalar'},mfilename,names{k});
end
assert(ismember(p.source_mode,[1 2 3]),'RLC:Source','Source mode must be 1 (DC), 2 (AC), or 3 (pulse).');
assert(p.frequency_Hz>0,'RLC:Frequency','AC frequency must be positive.');
assert(p.source_mode~=2 || p.voltage_V>=0,'RLC:RMS','AC RMS voltage must be nonnegative.');
positive={'R','L','C','Cth_R','Rth_R','Cth_C','Rth_C','turns', ...
    'core_area_m2','gap_m','period_s','stop_s','fps','animation_seconds','temperature_span_K'};
for k=1:numel(positive)
    assert(p.(positive{k})>0,'RLC:Positive','%s must be positive.',positive{k});
end
assert(p.Tamb_C>-273.15 && p.Tref_K>0,'RLC:Temperature','Temperature must exceed absolute zero.');
assert(p.ESR>=0 && p.alpha_R>=0 && p.alpha_ESR>=0,'RLC:Loss','ESR and coefficients must be nonnegative.');
assert(p.duty_pct>0 && p.duty_pct<=100,'RLC:Duty','Duty must be in (0,100].');
assert(p.fps==fix(p.fps) && p.fps>=1 && p.fps<=120,'RLC:FPS','FPS must be an integer from 1 to 120.');
assert(p.animation_seconds*p.fps>=2,'RLC:Frames','Animation needs at least two frames.');
assert(1+p.alpha_R*(p.Tamb_C+273.15-p.Tref_K)>0,'RLC:Resistance','Initial resistance must be positive.');
assert(1+p.alpha_ESR*(p.Tamb_C+273.15-p.Tref_K)>0,'RLC:ESR','Initial ESR factor must be positive.');
end

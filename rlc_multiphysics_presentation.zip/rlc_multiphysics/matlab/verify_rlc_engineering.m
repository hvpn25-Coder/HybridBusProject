function verify_rlc_engineering()
%VERIFY_RLC_ENGINEERING Exercise the real GUI comparison and numerical identities.
root=rlc_project_root(); folder=fullfile(root,'verification','engineering');
if ~isfolder(folder), mkdir(folder); end
p=rlc_defaults(); f0=1/(2*pi*sqrt(p.L*p.C));
s=rlc_frequency_response(p,[f0/10;f0;f0*10]);
assert(abs(s.current_rms_A(2)-p.voltage_V/(p.R+p.ESR))<1e-10);
assert(abs(s.current_phase_deg(2))<1e-10);
assert(s.current_phase_deg(1)>0 && s.current_phase_deg(3)<0);
hot=p; hot.Tamb_C=75; h=rlc_frequency_response(hot,f0);
assert(h.current_rms_A<s.current_rms_A(2));
negative=p; negative.voltage_V=-p.voltage_V;
n=rlc_frequency_response(negative,[f0/10;f0;f0*10]);
assert(isequal(n,s));
app=RLCApp; cleanup=onCleanup(@()delete(app));
app.compareDesigns();
assert(~isempty(app.Comparison),'GUI comparison failed; inspect status/log.');
c=app.Comparison;
assert(c.B.parameters.R==2*c.A.parameters.R);
assert(max(abs(c.B.data.i_L_A))<max(abs(c.A.data.i_L_A)));
residuals=[];
for result={c.A,c.B}
    d=result{1}.data;
    assert(all(diff(d.E_heat_J)>=-1e-12));
    assert(max(abs(d.source_V-d.v_R_V-d.v_L_V-d.v_ESR_V-d.v_C_V))<1e-10);
    % Logged heat power and electrical states are independently interpolated.
    powerError=max(abs(d.P_source_W-d.P_heat_W-d.P_inductor_W-d.P_capacitor_W));
    assert(powerError/max(max(abs(d.P_source_W)),1)<1e-4);
    residual=max(abs(d.E_balance_error_J))/max(max(abs(d.E_source_net_J)),1);
    assert(residual<.003,'Energy integration residual exceeds 0.3 percent.');
    residuals(end+1)=residual;
end
exportapp(app.UIFigure,fullfile(folder,'comparison_gui.png'));
transientTab=app.ComparisonAxes(3).Parent.Parent;
transientTab.Parent.SelectedTab=transientTab; drawnow;
exportapp(app.UIFigure,fullfile(folder,'comparison_transient.png'));
copyfile(fullfile(c.outputDir,'comparison_metrics.csv'),fullfile(folder,'comparison_metrics.csv'));
copyfile(fullfile(c.outputDir,'comparison.json'),fullfile(folder,'comparison.json'));
report=struct('passed',true,'comparison_output',c.outputDir,'f0_Hz',f0, ...
    'normalized_energy_residuals',residuals,'resonance_phase_temperature_checks',true);
app.BuildCheck.Value=false; app.RenderCheck.Value=false;
app.Fields.stop_s.Value=.03; app.SourceMode.Value=2; app.run();
assert(~isempty(app.Result) && ismember('E_heat_J',app.Result.data.Properties.VariableNames));
assert(strcmp(app.RunButton.Enable,'on') && strcmp(app.CompareButton.Enable,'on'));
report.single_run_regression=true;
fid=fopen(fullfile(folder,'report.json'),'w'); fprintf(fid,'%s',jsonencode(report)); fclose(fid);
disp(report); disp('ENGINEERING_GUI_AND_PHYSICS_PASS');
end

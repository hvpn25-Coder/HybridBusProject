function root = rlc_project_root()
%RLC_PROJECT_ROOT Locate project assets independently of the current folder.
root = fileparts(fileparts(mfilename('fullpath')));
end

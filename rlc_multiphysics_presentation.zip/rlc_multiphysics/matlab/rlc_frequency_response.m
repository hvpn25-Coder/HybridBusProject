function response=rlc_frequency_response(p,frequency_Hz)
%RLC_FREQUENCY_RESPONSE Linear sinusoidal response with R/ESR frozen at ambient.
% abs(voltage_V) is RMS here, regardless of transient source selection.
arguments
    p (1,1) struct
    frequency_Hz (:,1) double {mustBePositive,mustBeFinite}
end
validate_rlc_parameters(p);
temperature=p.Tamb_C+273.15;
r=p.R*(1+p.alpha_R*(temperature-p.Tref_K));
esr=p.ESR*(1+p.alpha_ESR*(temperature-p.Tref_K));
omega=2*pi*frequency_Hz;
impedance=r+esr+1i*(omega*p.L-1./(omega*p.C));
current=abs(p.voltage_V)./impedance;
response=table(frequency_Hz,abs(current),-angle(impedance)*180/pi, ...
    abs(current./(1i*omega*p.C)),abs(impedance), ...
    'VariableNames',{'frequency_Hz','current_rms_A','current_phase_deg','capacitor_rms_V','impedance_ohm'});
end

classdef RLCApp < handle
    %RLCAPP Programmatic App Designer-style control panel. Launch: app=RLCApp;
    properties (SetAccess=private)
        UIFigure
        Fields = struct
        RunButton
        BuildCheck
        RenderCheck
        BlenderPath
        SourceMode
        ModelBackend
        OpenModelButton
        RenderStyle
        VoltageLabel
        VideoLink
        VideoPath = ""
        Status
        ElectricalAxes
        ThermalAxes
        EnergyAxes
        Tabs
        ComparisonTab
        DesignBFields = struct
        CompareButton
        ComparisonAxes
        ComparisonTable
        ComparisonLink
        Comparison = []
        Result = []
        Job = []
    end
    properties (Access=private)
        PollTimer = []
        Busy = false
    end
    methods
        function app=RLCApp()
            app.UIFigure=uifigure('Name','Series RLC | Electro-thermal-magnetic','WindowState','maximized');
            g=uigridlayout(app.UIFigure,[5 1]);
            g.RowHeight={'fit','fit','fit','1x',64};
            inputs=uigridlayout(g,[2 7]); inputs.Layout.Row=1;
            labels={'Resistance (ohm)','Inductance (H)','Capacitance (F)', ...
                'Ambient (deg C)','Source (V)','Duration (s)'};
            keys={'R','L','C','Tamb_C','voltage_V','stop_s'};
            p=rlc_defaults();
            for k=1:6
                label=uilabel(inputs,'Text',labels{k}); label.Layout.Row=1; label.Layout.Column=k;
                if k==5, app.VoltageLabel=label; end
                field=uieditfield(inputs,'numeric','Value',p.(keys{k}));
                field.Layout.Row=2; field.Layout.Column=k;
                app.Fields.(keys{k})=field;
            end
            label=uilabel(inputs,'Text','Voltage source'); label.Layout.Row=1; label.Layout.Column=7;
            app.SourceMode=uidropdown(inputs,'Items',{'DC','AC (60 Hz)','Pulse (1 Hz)'}, ...
                'ItemsData',[1 2 3],'Value',p.source_mode, ...
                'ValueChangedFcn',@(~,~)app.updateSourceLabel());
            app.SourceMode.Layout.Row=2; app.SourceMode.Layout.Column=7;
            paths=uigridlayout(g,[1 5]); paths.Layout.Row=2; paths.ColumnWidth={'fit',270,'fit','1x',100};
            uilabel(paths,'Text','Simulation model');
            selected='basic'; if rlc_has_simscape(), selected='simscape'; end
            app.ModelBackend=uidropdown(paths,'Items',{'Basic Simulink blocks (no add-ons)','Simscape physical network'}, ...
                'ItemsData',{'basic','simscape'},'Value',selected);
            app.ModelBackend.Tooltip='Basic mode requires MATLAB and Simulink only; Simscape mode additionally requires Simscape.';
            uilabel(paths,'Text','Blender executable');
            app.BlenderPath=uieditfield(paths,'text','Value','C:\Tools\Blender\blender.exe');
            app.OpenModelButton=uibutton(paths,'Text','Open model','ButtonPushedFcn',@(~,~)app.openSelectedModel());
            actions=uigridlayout(g,[1 6]); actions.Layout.Row=3;
            actions.ColumnWidth={'fit','fit','fit',210,'fit','1x'};
            app.RunButton=uibutton(actions,'Text','Run Simulation','ButtonPushedFcn',@(~,~)app.run());
            app.BuildCheck=uicheckbox(actions,'Text','Update Blender scene','Value',isfile(app.BlenderPath.Value));
            app.RenderCheck=uicheckbox(actions,'Text','Render MP4','Value',isfile(app.BlenderPath.Value));
            app.RenderStyle=uidropdown(actions,'Items',{'Presentation | 1080p','Quick | 720p'}, ...
                'ItemsData',{'presentation','quick'},'Value','presentation');
            app.VideoLink=uihyperlink(actions,'Text','Open rendered video','Enable','off', ...
                'HyperlinkClickedFcn',@(~,~)app.openVideo());
            uilabel(actions,'Text','AC: 60 Hz, RMS voltage | Pulse: 50% duty | thermal scale: 10 K');
            demo=fullfile(rlc_project_root(),'media','quick','rlc_animation.mp4');
            presentation=fullfile(rlc_project_root(),'media','presentation','rlc_animation.mp4');
            presentationStatus=fullfile(fileparts(presentation),'blender_status.json');
            if isfile(presentation) && isfile(presentationStatus)
                state=jsondecode(fileread(presentationStatus));
                if strcmp(state.state,'complete') && state.rendered, demo=presentation; end
            end
            if isfile(demo)
                app.VideoPath=string(demo); app.VideoLink.Enable='on';
                app.VideoLink.Text='Open example video'; app.VideoLink.Tooltip=demo;
            end
            app.updateSourceLabel();
            app.Tabs=uitabgroup(g); app.Tabs.Layout.Row=4;
            transientTab=uitab(app.Tabs,'Title','Simulation');
            charts=uigridlayout(transientTab,[1 3]);
            app.ElectricalAxes=uiaxes(charts); title(app.ElectricalAxes,'Electrical response');
            app.ThermalAxes=uiaxes(charts); title(app.ThermalAxes,'Temperature rise');
            app.EnergyAxes=uiaxes(charts); title(app.EnergyAxes,'Stored energy');
            app.ComparisonTab=uitab(app.Tabs,'Title','Engineering comparison');
            comparison=uigridlayout(app.ComparisonTab,[3 1]);
            comparison.RowHeight={64,24,'1x'};
            choices=uigridlayout(comparison,[2 4]); choices.Layout.Row=1;
            choices.ColumnWidth={'1x','1x','1x',230};
            bkeys={'R','L','C'}; blabels={'Design B: resistance (ohm)','Design B: inductance (H)','Design B: capacitance (F)'};
            bvalues=[2*p.R,p.L,p.C];
            for k=1:3
                label=uilabel(choices,'Text',blabels{k}); label.Layout.Row=1; label.Layout.Column=k;
                field=uieditfield(choices,'numeric','Value',bvalues(k)); field.Layout.Row=2; field.Layout.Column=k;
                app.DesignBFields.(bkeys{k})=field;
            end
            label=uilabel(choices,'Text','Design A uses inputs above'); label.Layout.Row=1; label.Layout.Column=4;
            app.CompareButton=uibutton(choices,'Text','Run A/B comparison','ButtonPushedFcn',@(~,~)app.compareDesigns());
            app.CompareButton.Layout.Row=2; app.CompareButton.Layout.Column=4;
            notes=uigridlayout(comparison,[1 2]); notes.Layout.Row=2; notes.Padding=[0 0 0 0]; notes.ColumnWidth={'1x',150};
            uilabel(notes,'Text','Sweep: RMS = |input voltage|, R/ESR at ambient. Transients: selected source with thermal feedback.');
            app.ComparisonLink=uihyperlink(notes,'Text','Open comparison results','Enable','off', ...
                'HyperlinkClickedFcn',@(~,~)app.openComparisonResults());
            body=uigridlayout(comparison,[1 2]); body.Layout.Row=3; body.ColumnWidth={'1x',560};
            plotTabs=uitabgroup(body);
            frequencyTab=uitab(plotTabs,'Title','Frequency response');
            transientCompareTab=uitab(plotTabs,'Title','Transients and heating');
            frequencyPlots=uigridlayout(frequencyTab,[1 2]);
            transientPlots=uigridlayout(transientCompareTab,[1 2]);
            app.ComparisonAxes=gobjects(1,4);
            for k=1:2, app.ComparisonAxes(k)=uiaxes(frequencyPlots); end
            for k=3:4, app.ComparisonAxes(k)=uiaxes(transientPlots); end
            app.ComparisonTable=uitable(body,'ColumnName',{'Metric','Unit','Design A','Design B','B minus A'});
            app.Status=uitextarea(g,'Editable','off','Value',{'Ready. Set parameters and run.'});
            app.Status.Layout.Row=5;
            app.UIFigure.CloseRequestFcn=@(~,~)app.delete();
        end
        function run(app)
            if app.Busy, return; end
            app.Busy=true; app.RunButton.Enable='off'; app.CompareButton.Enable='off'; app.OpenModelButton.Enable='off';
            app.VideoPath=""; app.VideoLink.Enable='off';
            app.VideoLink.Text='Open rendered video'; app.VideoLink.Tooltip='Available after rendering completes.';
            guard=onCleanup(@()app.releaseSimulation());
            progress=[];
            try
                p=rlc_defaults(); keys=fieldnames(app.Fields);
                for k=1:numel(keys), p.(keys{k})=app.Fields.(keys{k}).Value; end
                p.source_mode=app.SourceMode.Value;
                p.frequency_Hz=60;
                validate_rlc_parameters(p);
                if app.RenderCheck.Value, app.BuildCheck.Value=true; end
                if app.BuildCheck.Value
                    assert(isfile(app.BlenderPath.Value),'RLC:Blender','Select a valid Blender executable.');
                end
                % Modal simulation avoids unsafe Simulink calls on thread workers.
                progress=uiprogressdlg(app.UIFigure,'Title','Simulating RLC circuit', ...
                    'Message',['Solving with ' app.ModelBackend.Value ' model and exporting data...'], ...
                    'Indeterminate','on','Cancelable','off');
                drawnow;
                root=rlc_project_root();
                if ~isfolder(fullfile(root,'runs')), mkdir(fullfile(root,'runs')); end
                runDir=string(tempname(fullfile(root,'runs')));
                mkdir(runDir);
                app.Result=run_rlc_simulation(p,runDir,"",string(app.ModelBackend.Value));
                close(progress); progress=[];
                app.plotResult();
                app.Status.Value={char("Simulation complete: "+runDir)};
                if app.Result.metadata.visual_aliasing_warning && strcmp(app.RenderStyle.Value,'quick')
                    app.Status.Value{end+1}='Fast electrical changes may be undersampled in the video; use the full-resolution CSV/MAT for analysis.';
                end
                if app.BuildCheck.Value
                    app.Job=launch_rlc_blender(app.Result.json,fullfile(runDir,'blender'), ...
                        string(app.BlenderPath.Value),app.RenderCheck.Value,string(app.RenderStyle.Value));
                    app.Status.Value=rlc_blender_progress_text(app.Job.progress,toc(app.Job.started));
                    app.PollTimer=timer('ExecutionMode','fixedSpacing','Period',1, ...
                        'TimerFcn',@(~,~)app.pollBlender());
                    start(app.PollTimer);
                end
            catch exception
                if ~isempty(progress) && isvalid(progress), close(progress); end
                app.Status.Value={exception.message};
                uialert(app.UIFigure,exception.message,'RLC workflow error');
            end
        end
        function openVideo(app)
            if strlength(app.VideoPath)==0 || ~isfile(app.VideoPath)
                app.VideoLink.Enable='off';
                uialert(app.UIFigure,'The rendered video is no longer available. Render the simulation again.','Video unavailable');
                return;
            end
            if ispc
                winopen(char(app.VideoPath));
            else
                uri=java.io.File(char(app.VideoPath)).toURI();
                java.awt.Desktop.getDesktop().open(java.io.File(uri));
            end
        end
        function compareDesigns(app)
            if app.Busy, return; end
            app.Busy=true; app.RunButton.Enable='off'; app.CompareButton.Enable='off'; app.OpenModelButton.Enable='off';
            guard=onCleanup(@()app.releaseSimulation());
            progress=[];
            try
                a=rlc_defaults(); keys=fieldnames(app.Fields);
                for k=1:numel(keys), a.(keys{k})=app.Fields.(keys{k}).Value; end
                a.source_mode=app.SourceMode.Value; a.frequency_Hz=60;
                b=a;
                for key={'R','L','C'}, b.(key{1})=app.DesignBFields.(key{1}).Value; end
                validate_rlc_parameters(a); validate_rlc_parameters(b);
                progress=uiprogressdlg(app.UIFigure,'Title','Comparing designs A and B', ...
                    'Message','Solving both electro-thermal models and calculating the frequency response...', ...
                    'Indeterminate','on','Cancelable','off'); drawnow;
                parent=fullfile(rlc_project_root(),'runs'); if ~isfolder(parent), mkdir(parent); end
                folder=string(tempname(parent)); mkdir(folder);
                app.Comparison=rlc_compare_designs(a,b,folder,string(app.ModelBackend.Value));
                close(progress); progress=[];
                app.plotComparison();
                app.Tabs.SelectedTab=app.ComparisonTab;
                app.Status.Value={char("A/B comparison complete: "+folder), ...
                    'CSV/JSON reports and both simulation datasets saved. B minus A is a signed difference, not a quality score.'};
                app.ComparisonLink.Enable='on';
                app.releaseSimulation();
                drawnow;
                exportapp(app.UIFigure,fullfile(folder,'comparison_dashboard.png'));
            catch exception
                if ~isempty(progress) && isvalid(progress), close(progress); end
                app.Status.Value={exception.message};
                uialert(app.UIFigure,exception.message,'Comparison error');
            end
        end
        function openComparisonResults(app)
            if isempty(app.Comparison) || ~isfolder(app.Comparison.outputDir), return; end
            if ispc, winopen(char(app.Comparison.outputDir));
            else, java.awt.Desktop.getDesktop().open(java.io.File(char(app.Comparison.outputDir))); end
        end
        function openSelectedModel(app)
            if app.Busy, return; end
            try
                if strcmp(app.ModelBackend.Value,'basic')
                    model=open_rlc_basic_model(); open_system(model);
                else
                    assert(rlc_has_simscape(),'RLC:SimscapeUnavailable', ...
                        'Simscape is unavailable. Choose Basic Simulink blocks.');
                    build_rlc_model();
                end
            catch exception
                uialert(app.UIFigure,exception.message,'Model unavailable');
            end
        end
        function delete(app)
            if ~isempty(app.PollTimer) && isvalid(app.PollTimer)
                stop(app.PollTimer); delete(app.PollTimer);
            end
            % Closing the app ends only its own active Blender child process.
            if ~isempty(app.Job) && app.Job.process.isAlive(), app.Job.process.destroy(); end
            if ~isempty(app.UIFigure) && isvalid(app.UIFigure), delete(app.UIFigure); end
        end
    end
    methods (Access=private)
        function updateSourceLabel(app)
            if app.SourceMode.Value==2
                app.VoltageLabel.Text='AC voltage (V RMS)';
            elseif app.SourceMode.Value==1
                app.VoltageLabel.Text='DC voltage (V)';
            else
                app.VoltageLabel.Text='Pulse amplitude (V)';
            end
        end
        function releaseSimulation(app)
            if ~isvalid(app.UIFigure), return; end
            if isempty(app.Job) || ~app.Job.process.isAlive()
                app.Busy=false; app.RunButton.Enable='on'; app.CompareButton.Enable='on'; app.OpenModelButton.Enable='on';
            end
        end
        function plotResult(app)
            d=app.Result.data;
            ax=app.ElectricalAxes; cla(ax);
            yyaxis(ax,'left'); plot(ax,d.time_s,d.i_L_A); ylabel(ax,'Current (A)');
            yyaxis(ax,'right'); plot(ax,d.time_s,d.v_C_V); ylabel(ax,'Capacitor voltage (V)');
            xlabel(ax,'Time (s)'); grid(ax,'on');
            ax=app.ThermalAxes;
            plot(ax,d.time_s,[d.T_R_K-d.T_amb_K,d.T_C_K-d.T_amb_K]);
            xlabel(ax,'Time (s)'); ylabel(ax,'Rise above ambient (K)');
            legend(ax,{'Resistor','Capacitor'},'Location','best'); grid(ax,'on');
            ax=app.EnergyAxes;
            plot(ax,d.time_s,[d.W_magnetic_J,d.W_electric_J]);
            xlabel(ax,'Time (s)'); ylabel(ax,'Energy (J)');
            legend(ax,{'Magnetic','Electric'},'Location','best'); grid(ax,'on');
        end
        function pollBlender(app)
            if app.Job.process.isAlive()
                app.Status.Value=rlc_blender_progress_text(app.Job.progress,toc(app.Job.started));
                return;
            end
            stop(app.PollTimer); delete(app.PollTimer); app.PollTimer=[];
            code=app.Job.process.exitValue();
            if code==0 && isfile(app.Job.status)
                state=jsondecode(fileread(app.Job.status));
                if strcmp(state.state,'complete')
                    app.Status.Value={char("Complete: "+app.Job.outputDir), ...
                        'Open rlc_animation.blend in Blender; press Space to play.'};
                    video=fullfile(app.Job.outputDir,'rlc_animation.mp4');
                    if state.rendered && isfile(video)
                        app.VideoPath=string(video); app.VideoLink.Enable='on';
                        app.VideoLink.Tooltip=char(video);
                        app.Status.Value{end+1}='Video ready. Click Open rendered video above.';
                    else
                        app.Status.Value{end+1}='Scene ready; select Render MP4 for a video link.';
                    end
                else
                    app.Status.Value={['Blender failed: ' state.message],char(app.Job.log)};
                end
            else
                app.Status.Value={sprintf('Blender exited with code %d. See log:',code),char(app.Job.log)};
            end
            app.Busy=false; app.RunButton.Enable='on'; app.CompareButton.Enable='on'; app.OpenModelButton.Enable='on';
        end
        function plotComparison(app)
            c=app.Comparison; a=c.A.data; b=c.B.data;
            ax=app.ComparisonAxes(1); cla(ax);
            semilogx(ax,c.sweepA.frequency_Hz,c.sweepA.current_rms_A,c.sweepB.frequency_Hz,c.sweepB.current_rms_A,'LineWidth',1.4);
            xlabel(ax,'Frequency (Hz)'); ylabel(ax,'Current RMS (A)'); title(ax,'Resonance | resistance fixed at ambient');
            ax=app.ComparisonAxes(2); cla(ax);
            semilogx(ax,c.sweepA.frequency_Hz,c.sweepA.current_phase_deg,c.sweepB.frequency_Hz,c.sweepB.current_phase_deg,'LineWidth',1.4);
            xlabel(ax,'Frequency (Hz)'); ylabel(ax,'Current phase (deg)'); title(ax,'Phase relative to source');
            ax=app.ComparisonAxes(3); cla(ax);
            plot(ax,a.time_s,a.i_L_A,b.time_s,b.i_L_A,'LineWidth',1.1);
            xlabel(ax,'Physical time (s)'); ylabel(ax,'Current (A)'); title(ax,'Electro-thermal transient');
            ax=app.ComparisonAxes(4); cla(ax);
            plot(ax,a.time_s,a.T_R_K-a.T_amb_K,b.time_s,b.T_R_K-b.T_amb_K,'LineWidth',1.4);
            xlabel(ax,'Physical time (s)'); ylabel(ax,'Resistor rise (K)'); title(ax,'Heating comparison');
            for ax=app.ComparisonAxes, grid(ax,'on'); legend(ax,{'Design A','Design B'},'Location','best'); end
            app.ComparisonTable.Data=table2cell(c.summary);
            app.ComparisonTable.ColumnWidth={185,40,80,80,85};
        end
    end
end

function study=rlc_compare_designs(a,b,outputDir,backend)
%RLC_COMPARE_DESIGNS Compare two RLC designs under the same excitation/ambient.
arguments
    a (1,1) struct
    b (1,1) struct
    outputDir (1,1) string
    backend (1,1) string {mustBeMember(backend,["simscape","basic"])} = "simscape"
end
validate_rlc_parameters(a); validate_rlc_parameters(b);
shared={'source_mode','voltage_V','frequency_Hz','period_s','duty_pct','stop_s','Tamb_C'};
for k=1:numel(shared)
    assert(isequal(a.(shared{k}),b.(shared{k})),'RLC:Comparison','Both designs must share %s.',shared{k});
end
if ~isfolder(outputDir), mkdir(outputDir); end
A=run_rlc_simulation(a,fullfile(outputDir,'design_A'),"",backend);
B=run_rlc_simulation(b,fullfile(outputDir,'design_B'),"",backend);
f0=[1/(2*pi*sqrt(a.L*a.C)),1/(2*pi*sqrt(b.L*b.C))];
frequency=unique(sort([logspace(log10(min([f0,60])/100),log10(max([f0,60])*100),700),f0,60]))';
sweepA=rlc_frequency_response(a,frequency); sweepB=rlc_frequency_response(b,frequency);
metric={'Resistance at 25 C';'Inductance';'Capacitance';'LC resonance';'Quality factor at ambient'; ...
    'Damping ratio at ambient';'Peak absolute current';'Peak absolute capacitor voltage'; ...
    'Final resistor rise';'Final capacitor rise';'Heat generated';'Net source energy'; ...
    'Peak magnetic energy';'Peak electric energy';'Max energy-balance residual'};
unit={'ohm';'H';'F';'Hz';'1';'1';'A';'V';'K';'K';'J';'J';'J';'J';'J'};
va=metrics(A); vb=metrics(B);
summary=table(metric,unit,va,vb,vb-va,'VariableNames',{'Metric','Unit','Design_A','Design_B','B_minus_A'});
summary=summary([7:11,4:6,12:15,1:3],:);
writetable(summary,fullfile(outputDir,'comparison_metrics.csv'));
writetable(sweepA,fullfile(outputDir,'frequency_design_A.csv'));
writetable(sweepB,fullfile(outputDir,'frequency_design_B.csv'));
notes=struct('transient_source',A.metadata.source_description,'duration_s',a.stop_s,'model_backend',char(backend), ...
    'sweep_assumption','Sinusoidal RMS input equal to abs(voltage_V); R and ESR frozen at ambient; no thermal steady-state sweep.', ...
    'scope','Lumped linear L/C with temperature-dependent R and capacitor ESR. No winding/core loss or spatial FEM.', ...
    'design_A',a,'design_B',b,'summary',table2struct(summary));
fid=fopen(fullfile(outputDir,'comparison.json'),'w'); assert(fid~=-1);
closer=onCleanup(@()fclose(fid)); fprintf(fid,'%s',jsonencode(notes)); clear closer;
study=struct('A',A,'B',B,'sweepA',sweepA,'sweepB',sweepB,'summary',summary,'outputDir',outputDir);
end

function values=metrics(result)
p=result.parameters; d=result.data;
r=p.R*(1+p.alpha_R*(p.Tamb_C+273.15-p.Tref_K));
esr=p.ESR*(1+p.alpha_ESR*(p.Tamb_C+273.15-p.Tref_K));
q=sqrt(p.L/p.C)/(r+esr);
values=[p.R;p.L;p.C;1/(2*pi*sqrt(p.L*p.C));q;1/(2*q); ...
    max(abs(d.i_L_A));max(abs(d.v_C_V));d.T_R_K(end)-d.T_amb_K(end); ...
    d.T_C_K(end)-d.T_amb_K(end);d.E_heat_J(end);d.E_source_net_J(end); ...
    max(d.W_magnetic_J);max(d.W_electric_J);max(abs(d.E_balance_error_J))];
end

function dt = rlc_max_step(p)
%RLC_MAX_STEP Resolve LC dynamics and the active source waveform.
dt=min([2*pi*sqrt(p.L*p.C)/80,0.005]);
if p.source_mode==2
    dt=min(dt,1/(100*p.frequency_Hz));
elseif p.source_mode==3
    dt=min(dt,p.period_s/100);
end
end

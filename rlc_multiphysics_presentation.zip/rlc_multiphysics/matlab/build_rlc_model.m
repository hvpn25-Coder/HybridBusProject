function model = build_rlc_model(model)
%BUILD_RLC_MODEL Build a standalone series electrical/thermal Simscape model.
% Existing models are opened, not overwritten. Delete/rename a model explicitly
% before rebuilding it. This function needs no MCP or agent tooling.
arguments
    model (1,1) string = "rlc_multiphysics_model"
end
assert(isvarname(model),'RLC:ModelName','Use a valid MATLAB identifier.');
root = fileparts(mfilename('fullpath'));
addpath(root);
previous = pwd; cleanup = onCleanup(@() cd(previous)); cd(root);
libfile = fullfile(root,'rlcphysics_lib.slx');
if ~isfile(libfile)
    if exist('sscbuild','file'), sscbuild('rlcphysics');
    else, ssc_build('rlcphysics'); end
end
file = fullfile(root,model+'.slx');
if bdIsLoaded(model), open_system(model); return; end
if isfile(file), open_system(file); return; end
load_system('rlcphysics_lib'); load_system('fl_lib'); load_system('nesl_utility');
new_system(model); open_system(model);
assignin(get_param(model,'ModelWorkspace'),'p',rlc_defaults());
b = struct;
b.Excitation = add_block('simulink/Sources/Pulse Generator',model+'/Excitation', ...
    'Amplitude','p.voltage_V','Period','p.period_s','PulseWidth','p.duty_pct', ...
    'PhaseDelay','0','Position',[35 35 100 75]);
b.DCSource = add_block('simulink/Sources/Constant',model+'/DCSource','Value','p.voltage_V', ...
    'Position',[20 100 80 130]);
b.ACSource = add_block('simulink/Sources/Sine Wave',model+'/ACSource', ...
    'Amplitude','sqrt(2)*p.voltage_V','Frequency','2*pi*p.frequency_Hz', ...
    'Phase','0','Bias','0','SampleTime','0','Position',[20 160 80 190]);
b.SourceMode = add_block('simulink/Sources/Constant',model+'/SourceMode','Value','p.source_mode', ...
    'Position',[20 210 80 240]);
b.SourceSelector = add_block('simulink/Signal Routing/Multiport Switch',model+'/SourceSelector', ...
    'Inputs','3','DataPortOrder','One-based contiguous','Position',[135 115 180 195]);
b.VoltageCommand = add_block(sprintf('nesl_utility/Simulink-PS\nConverter'),model+'/VoltageCommand', ...
    'Unit','V','Position',[145 35 190 75]);
b.VoltageSource = add_block(sprintf('fl_lib/Electrical/Electrical Sources/Controlled Voltage\nSource'), ...
    model+'/VoltageSource','Position',[240 105 290 165]);
b.Resistor = add_block('rlcphysics_lib/ThermalResistor',model+'/Resistor', ...
    'R0','p.R','alpha','p.alpha_R','Tref','p.Tref_K','Tinit','p.Tamb_C+273.15', ...
    'Cth','p.Cth_R','Rth','p.Rth_R','Position',[360 100 440 160]);
b.Inductor = add_block('rlcphysics_lib/FluxInductor',model+'/Inductor', ...
    'L','p.L','N','p.turns','Acore','p.core_area_m2','Position',[510 100 590 160]);
b.Capacitor = add_block('rlcphysics_lib/ThermalCapacitor',model+'/Capacitor', ...
    'C','p.C','ESR0','p.ESR','alpha','p.alpha_ESR','Tref','p.Tref_K', ...
    'Tinit','p.Tamb_C+273.15','Cth','p.Cth_C','Rth','p.Rth_C', ...
    'gap','p.gap_m','Position',[660 100 740 160]);
b.ElectricalReference = add_block('fl_lib/Electrical/Electrical Elements/Electrical Reference', ...
    model+'/ElectricalReference','Position',[235 260 275 300]);
b.SolverConfiguration = add_block(sprintf('nesl_utility/Solver\nConfiguration'), ...
    model+'/SolverConfiguration','Position',[120 240 180 290]);
b.Ambient = add_block('fl_lib/Thermal/Thermal Sources/Temperature Source',model+'/Ambient', ...
    'temperature','p.Tamb_C+273.15','temperature_unit','K','Position',[490 250 550 310]);
ports = struct; names=fieldnames(b);
for k=1:numel(names), ports.(names{k})=get_param(b.(names{k}),'PortHandles'); end
wire(ports.SourceMode.Outport,ports.SourceSelector.Inport(1));
wire(ports.DCSource.Outport,ports.SourceSelector.Inport(2));
wire(ports.ACSource.Outport,ports.SourceSelector.Inport(3));
wire(ports.Excitation.Outport,ports.SourceSelector.Inport(4));
wire(ports.SourceSelector.Outport,ports.VoltageCommand.Inport);
wire(ports.VoltageCommand.RConn(1),ports.VoltageSource.RConn(1));
wire(ports.VoltageSource.LConn(1),ports.Resistor.LConn(1));
wire(ports.Resistor.RConn(1),ports.Inductor.LConn(1));
wire(ports.Inductor.RConn(1),ports.Capacitor.LConn(1));
wire(ports.Capacitor.RConn(1),ports.VoltageSource.RConn(2));
wire(ports.VoltageSource.RConn(2),ports.ElectricalReference.LConn(1));
wire(ports.SolverConfiguration.RConn(1),ports.ElectricalReference.LConn(1));
wire(ports.Resistor.RConn(2),ports.Ambient.LConn(1));
wire(ports.Capacitor.RConn(2),ports.Ambient.LConn(1));
set_param(model,'Solver','ode23t','StopTime','p.stop_s','RelTol','1e-6', ...
    'AbsTol','1e-8','MaxStep','rlc_max_step(p)', ...
    'SimscapeLogType','all','SimscapeLogName','simlog_rlc', ...
    'SimscapeLogLimitData','off','ReturnWorkspaceOutputs','on');
save_system(model,file);
    function wire(a,z)
        add_line(model,a,z,'autorouting','on');
    end
end

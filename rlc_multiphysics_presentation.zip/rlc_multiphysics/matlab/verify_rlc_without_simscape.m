function verify_rlc_without_simscape()
%VERIFY_RLC_WITHOUT_SIMSCAPE Run in a fresh MATLAB session with physmod paths removed.
root=rlc_project_root(); folder=fullfile(root,'verification','basic_simulink','without_simscape');
if ~isfolder(folder), mkdir(folder); end
oldPath=path; restorePath=onCleanup(@()path(oldPath));
entries=strsplit(path,pathsep);
remove=entries(contains(lower(entries),[filesep 'physmod' filesep]));
if ~isempty(remove), rmpath(strjoin(remove,pathsep)); end
assert(~rlc_has_simscape(),'Simscape functions are still available on the restricted path.');
assert(isempty(which('sscbuild')) && isempty(which('ssc_build')));
app=RLCApp; cleanup=onCleanup(@()delete(app));
assert(strcmp(app.ModelBackend.Value,'basic'),'GUI should select basic when Simscape is unavailable.');
app.BuildCheck.Value=false; app.RenderCheck.Value=false;
app.Fields.stop_s.Value=.12;
for mode=1:3
    app.SourceMode.Value=mode; app.run();
    assert(~isempty(app.Result) && strcmp(app.Result.metadata.model_backend,'basic'));
    assert(app.Result.parameters.source_mode==mode);
end
app.compareDesigns();
assert(~isempty(app.Comparison));
assert(strcmp(app.Comparison.A.metadata.model_backend,'basic') && strcmp(app.Comparison.B.metadata.model_backend,'basic'));
assert(strcmp(app.CompareButton.Enable,'on') && strcmp(app.RunButton.Enable,'on'));
app.openSelectedModel();
drawnow; pause(2); exportapp(app.UIFigure,fullfile(folder,'gui_basic_comparison.png'));
tabs=app.Tabs.Children;
app.Tabs.SelectedTab=tabs(strcmp({tabs.Title},'Simulation')); drawnow; pause(2);
exportapp(app.UIFigure,fullfile(folder,'gui_basic_simulation.png'));
licenses=license('inuse');
assert(~any(strcmpi({licenses.feature},'Simscape')),'A Simscape license was checked out.');
report=struct('passed',true,'removed_physmod_paths',numel(remove), ...
    'simscape_available_during_test',false,'gui_default','basic', ...
    'sources_tested',{{'DC','AC60Hz','Pulse'}},'comparison_backend','basic', ...
    'licenses_in_use',{{licenses.feature}},'comparison_output',app.Comparison.outputDir, ...
    'last_single_run',app.Result.outputDir);
fid=fopen(fullfile(folder,'report.json'),'w'); fprintf(fid,'%s',jsonencode(report)); fclose(fid);
disp(report); disp('NO_SIMSCAPE_GUI_AND_SIMULATION_PASS');
end

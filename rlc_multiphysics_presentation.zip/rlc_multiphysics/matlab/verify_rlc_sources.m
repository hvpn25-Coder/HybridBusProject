function report=verify_rlc_sources()
%VERIFY_RLC_SOURCES Check applied source, RMS convention, and circuit response.
root=rlc_project_root();
p=rlc_defaults(); p.stop_s=1; p.alpha_R=0; p.alpha_ESR=0;
errors=zeros(1,3);
for mode=1:3
    p.source_mode=mode;
    r=run_rlc_simulation(p,fullfile(root,'verification',sprintf('source_%d',mode)));
    native=load(fullfile(r.outputDir,'rlc_results.mat'),'out');
    source=native.out.simlog_rlc.VoltageSource.v.series;
    expected=rlc_source_voltage(source.time,p);
    measured=source.values('V');
    % Ignore exact switching instants for pulse left/right-limit conventions.
    valid=true(size(expected));
    if mode==3
        phase=mod(source.time,p.period_s);
        valid=phase>1e-8 & abs(phase-p.period_s*p.duty_pct/100)>1e-8;
    end
    errors(mode)=max(abs(measured(valid)-expected(valid)));
    assert(errors(mode)<1e-6,'RLC:SourceMismatch','Applied source differs from requested waveform.');
    if mode==1
        assert(abs(r.data.v_C_V(end)-p.voltage_V)<0.002);
        assert(abs(r.data.i_L_A(end))<0.001);
    elseif mode==2
        rmsVoltage=sqrt(trapz(r.data.time_s,r.data.source_V.^2)/p.stop_s);
        assert(abs(rmsVoltage-p.voltage_V)<1e-6);
        w=2*pi*p.frequency_Hz; resistance=p.R+p.ESR;
        reactance=w*p.L-1/(w*p.C);
        steady=sqrt(2)*p.voltage_V/hypot(resistance,reactance)* ...
            sin(w*r.data.time_s-atan2(reactance,resistance));
        late=r.data.time_s>0.8;
        currentError=max(abs(r.data.i_L_A(late)-steady(late)));
        assert(currentError<0.002,'RLC:ACResponse','AC response does not match impedance prediction.');
        assert(r.metadata.visual_aliasing_warning);
    end
end
report=struct('passed',true,'source_max_error_V',errors, ...
    'ac_frequency_Hz',60,'ac_rms_V',rmsVoltage,'ac_late_current_error_A',currentError);
fid=fopen(fullfile(root,'verification','source_report.json'),'w');
closer=onCleanup(@()fclose(fid)); fprintf(fid,'%s',jsonencode(report,PrettyPrint=true));
disp(report);
end

function result = run_rlc_simulation(p, outputDir, model, backend)
%RUN_RLC_SIMULATION Simulate, resample and export physical SI data and metadata.
arguments
    p (1,1) struct = rlc_defaults()
    outputDir (1,1) string = fullfile(rlc_project_root(),'data','default')
    model (1,1) string = ""
    backend (1,1) string {mustBeMember(backend,["simscape","basic"])} = "simscape"
end
validate_rlc_parameters(p);
previousFiles=Simulink.fileGenControl('getConfig');
restoreFiles=onCleanup(@()Simulink.fileGenControl('setConfig','config',previousFiles));
Simulink.fileGenControl('set','CacheFolder',fullfile(rlc_project_root(),'cache'), ...
    'CodeGenFolder',fullfile(rlc_project_root(),'cache','codegen'),'createDir',true);
if backend=="basic"
    if strlength(model)==0, model="rlc_basic_model"; end
    model=open_rlc_basic_model(model);
else
    assert(rlc_has_simscape(),'RLC:SimscapeUnavailable', ...
        'Simscape is unavailable. Select Basic Simulink blocks in the GUI.');
    if strlength(model)==0, model="rlc_multiphysics_model"; end
    model=build_rlc_model(model);
end
if ~isfolder(outputDir), mkdir(outputDir); end
in=Simulink.SimulationInput(model);
in=in.setVariable('p',p,'Workspace',model);
in=in.setModelParameter('MaxStep',num2str(rlc_max_step(p),17));
out=sim(in);
% Preserve native solver samples in MAT; export a fine common time grid.
dt=min([p.stop_s/6000,2*pi*sqrt(p.L*p.C)/100,p.period_s/200,rlc_max_step(p)]);
assert(ceil(p.stop_s/dt)<2e6,'RLC:DatasetSize', ...
    'Requested time scales create over 2 million samples. Shorten stop_s.');
t=linspace(0,p.stop_s,ceil(p.stop_s/dt)+1)';
d=table(t,'VariableNames',{'time_s'});
if backend=="simscape"
log=out.simlog_rlc;
d.i_L_A=sample(log.Inductor.i,'A');
d.v_C_V=sample(log.Capacitor.vc,'V');
d.v_C_terminal_V=sample(log.Capacitor.v,'V');
d.flux_linkage_Wb_turn=sample(log.Inductor.lambda,'Wb');
d.Phi_Wb=sample(log.Inductor.Phi,'Wb');
d.B_T=sample(log.Inductor.B,'T');
d.charge_C=sample(log.Capacitor.q,'C');
d.E_V_per_m=sample(log.Capacitor.E,'V/m');
d.T_R_K=sample(log.Resistor.T,'K');
d.T_C_K=sample(log.Capacitor.T,'K');
d.T_amb_K=repmat(p.Tamb_C+273.15,size(t));
d.R_ohm=sample(log.Resistor.R,'Ohm');
d.ESR_ohm=sample(log.Capacitor.ESR,'Ohm');
d.P_R_W=sample(log.Resistor.Pheat,'W');
d.P_C_W=sample(log.Capacitor.Pheat,'W');
d.W_magnetic_J=sample(log.Inductor.Wmag,'J');
d.W_electric_J=sample(log.Capacitor.Welec,'J');
else
    % Four states are solved by continuous Integrator blocks, not MATLAB ODE code.
    raw=out.basic_states;
    [nativeTime,ix]=unique(raw.Time,'last');
    nativeStates=reshape(raw.Data,numel(raw.Time),[]);
    state=interp1(nativeTime,nativeStates(ix,1:4),t,'linear');
    d.i_L_A=state(:,1); d.v_C_V=state(:,2);
    d.T_R_K=state(:,3); d.T_C_K=state(:,4);
    d.T_amb_K=repmat(p.Tamb_C+273.15,size(t));
    d.R_ohm=p.R*(1+p.alpha_R*(d.T_R_K-p.Tref_K));
    d.ESR_ohm=p.ESR*(1+p.alpha_ESR*(d.T_C_K-p.Tref_K));
    d.v_C_terminal_V=d.v_C_V+d.i_L_A.*d.ESR_ohm;
    d.flux_linkage_Wb_turn=p.L*d.i_L_A;
    d.Phi_Wb=d.flux_linkage_Wb_turn/p.turns;
    d.B_T=d.Phi_Wb/p.core_area_m2;
    d.charge_C=p.C*d.v_C_V;
    d.E_V_per_m=d.v_C_V/p.gap_m;
    d.P_R_W=d.i_L_A.^2.*d.R_ohm;
    d.P_C_W=d.i_L_A.^2.*d.ESR_ohm;
    d.W_magnetic_J=.5*p.L*d.i_L_A.^2;
    d.W_electric_J=.5*p.C*d.v_C_V.^2;
    % Match the existing CSV/MAT column order as well as field names.
    d=d(:,{'time_s','i_L_A','v_C_V','v_C_terminal_V','flux_linkage_Wb_turn', ...
        'Phi_Wb','B_T','charge_C','E_V_per_m','T_R_K','T_C_K','T_amb_K', ...
        'R_ohm','ESR_ohm','P_R_W','P_C_W','W_magnetic_J','W_electric_J'});
end
d.source_V=rlc_source_voltage(t,p);
d=rlc_energy_accounting(d);
assert(all(isfinite(d{:,:}),'all'),'RLC:Nonfinite','Simulation produced nonfinite data.');
meta=struct('schema_version',1,'parameters',p, ...
    'model',char(model),'model_backend',char(backend),'matlab_release',version('-release'), ...
    'temperature_unit','K','voltage_definition','v_C excludes ESR voltage drop', ...
    'field_model','Phi=L*i/N; B=Phi/Acore; E=v_C/gap; linear lumped model', ...
    'animation_time_mapping','uniform physical time mapped onto animation_seconds', ...
    'voltage_scale_V',max(abs(p.voltage_V),1), ...
    'current_scale_A',max(abs(p.voltage_V)/(p.R+p.ESR),0.01), ...
    'temperature_span_K',p.temperature_span_K);
meta.visual_sampling_hz=(round(p.animation_seconds*p.fps)-1)/p.stop_s;
meta.natural_frequency_hz=1/(2*pi*sqrt(p.L*p.C));
names={'DC','AC 60 Hz','Pulse'};
meta.source_description=names{p.source_mode};
meta.source_frequency_hz=0;
if p.source_mode==2
    meta.source_frequency_hz=p.frequency_Hz;
    meta.source_description=sprintf('AC %g Hz (V RMS)',p.frequency_Hz);
    meta.voltage_scale_V=sqrt(2)*max(abs(p.voltage_V),1);
end
meta.visual_aliasing_warning=meta.visual_sampling_hz<10*max(meta.natural_frequency_hz,meta.source_frequency_hz);
meta.visualization_note='Field brightness and thermal colors are normalized explanatory overlays; geometry is not to scale.';
csvPath=fullfile(outputDir,'rlc_data.csv');
jsonPath=fullfile(outputDir,'rlc_data.json');
writetable(d,csvPath);
payload=struct('metadata',meta,'data',table2struct(d,'ToScalar',true));
fid=fopen(jsonPath,'w','n','UTF-8'); assert(fid~=-1,'RLC:File','Cannot write JSON.');
closer=onCleanup(@() fclose(fid));
fprintf(fid,'%s',jsonencode(payload)); clear closer;
save(fullfile(outputDir,'rlc_results.mat'),'out','d','p','meta','-v7.3');
result=struct('data',d,'parameters',p,'metadata',meta,'csv',csvPath, ...
    'json',jsonPath,'outputDir',outputDir);
    function y=sample(node,unit)
        tt=node.series.time; yy=node.series.values(unit);
        [tt,ix]=unique(tt,'last');
        y=interp1(tt,yy(ix),t,'linear');
    end
end

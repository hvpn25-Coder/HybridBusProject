"""Live progress for the MATLAB GUI; not needed to play saved Blender scenes."""
import json
import time
from pathlib import Path

import bpy


def publish(output, phase, **values):
    path = Path(output) / 'blender_progress.json'
    payload = {'phase': phase, 'updated_unix_s': time.time(), **values}
    temporary = path.with_suffix('.tmp')
    try:
        temporary.write_text(json.dumps(payload), encoding='utf-8')
        temporary.replace(path)
    except OSError:
        # Progress is advisory: a transient Windows file lock must not kill rendering.
        pass


def render_animation(scene, output):
    started = time.monotonic()
    previous = started
    timings = []
    total = len(range(scene.frame_start, scene.frame_end + 1, scene.frame_step))
    publish(output, 'rendering', completed=0, total=total, eta_seconds=None)

    def completed_frame(render_scene, *unused):
        nonlocal previous
        if render_scene != scene:
            return
        now = time.monotonic()
        timings.append(now - previous)
        previous = now
        count = len(timings)
        recent = timings[-30:]
        seconds_per_frame = .7 * sum(recent)/len(recent) + .3 * (now-started)/count
        eta = seconds_per_frame * max(0, total-count) if count >= 3 else None
        publish(output, 'rendering', completed=count, total=total,
                eta_seconds=eta, render_elapsed_seconds=now-started)

    bpy.app.handlers.render_post.append(completed_frame)
    try:
        bpy.ops.render.render(animation=True)
        publish(output, 'finalizing', completed=total, total=total, eta_seconds=None)
    finally:
        bpy.app.handlers.render_post.remove(completed_frame)

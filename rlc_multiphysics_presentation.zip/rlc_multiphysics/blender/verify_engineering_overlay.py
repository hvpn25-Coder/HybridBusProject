"""Run with Blender and a saved presentation to audit baked numeric glyphs."""
import bisect
import csv
import json
from pathlib import Path
import bpy

root=Path(__file__).resolve().parents[1]
scene=bpy.context.scene
folder=Path(bpy.data.filepath).parent
data=json.loads((root/'data/default/rlc_data.json').read_text())['data']
rows=list(csv.DictReader((folder/'frame_mapping.csv').open()))
ts=data['time_s']; losses=[r+c for r,c in zip(data['P_R_W'],data['P_C_W'])]
heat=[0.0]
for j in range(1,len(ts)): heat.append(heat[-1]+(ts[j]-ts[j-1])*(losses[j]+losses[j-1])/2)
def interpolate(values,t):
    j=min(max(bisect.bisect_right(ts,t)-1,0),len(ts)-2)
    u=(t-ts[j])/(ts[j+1]-ts[j])
    return values[j]*(1-u)+values[j+1]*u
camera=scene.camera
w=camera.data.sensor_width/camera.data.lens
h=w/(scene.render.resolution_x/scene.render.resolution_y)
def glyph_group(x,y,size):
    group=[ob for ob in scene.objects if ob.type=='FONT' and ob.parent and
           ob.parent.name=='Presentation graphics' and abs(ob.location.y-(y-.5)*h)<1e-6 and
           (x-.5)*w-1e-6<=ob.location.x<=(x-.5+7*size*.32)*w+1e-6]
    return sorted(group,key=lambda ob:ob.location.x)
groups=[glyph_group(.055+j*.181,.108,.024) for j in range(5)]
volts=[glyph_group(x-.045,.662,.020) for x in [.19,.32,.45,.56]]
def text(value,fmt):
    result=format(value,fmt)
    if len(result)>8: result=f'{float(result):+.1e}'
    if len(result)>8: result=f'{float(result):+.0e}'
    return result
def check(group,expected):
    actual=''.join(ob.data.body for ob in group if not ob.hide_render)
    assert actual==expected,(scene.frame_current,actual,expected)
for row in rows:
    scene.frame_set(int(row['frame'])); t=float(row['physical_time_s'])
    i=interpolate(data['i_L_A'],t); vs=interpolate(data['source_V'],t); vc=interpolate(data['v_C_V'],t)
    vr=i*interpolate(data['R_ohm'],t); ve=i*interpolate(data['ESR_ohm'],t)
    values=[vs*i,interpolate(data['W_magnetic_J'],t),interpolate(data['W_electric_J'],t),
            interpolate(data['P_R_W'],t)+interpolate(data['P_C_W'],t),interpolate(heat,t)]
    for group,value in zip(groups,values): check(group,text(value,'+.3g'))
    for group,value in zip(volts,[vr,vs-vr-ve-vc,vc,ve]): check(group,text(value,'+.2f'))
report={'passed':True,'frames':len(rows),'baked_readouts_checked':len(rows)*9}
(root/'verification/engineering/overlay_report.json').write_text(json.dumps(report,indent=2))
print('ENGINEERING_OVERLAY_PASS',json.dumps(report))

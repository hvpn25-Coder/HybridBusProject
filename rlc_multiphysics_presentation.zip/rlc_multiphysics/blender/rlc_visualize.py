"""Build a portable, keyframed Blender scene from run_rlc_simulation's JSON.

blender --background --python rlc_visualize.py -- --data rlc_data.json
        --output fresh_output_directory [--render] [--width 1280] [--height 720]
Playback needs no pip packages, runtime handlers, or MATLAB connection.
"""
import argparse
import bisect
import json
import math
import sys
import traceback
from pathlib import Path

import bpy
from mathutils import Vector
sys.path.insert(0, str(Path(__file__).parent))
from render_progress import publish, render_animation


def enum(obj, name, value):
    choices = [x.identifier for x in obj.bl_rna.properties[name].enum_items]
    if value not in choices:
        raise ValueError(f"{name}={value} not available: {choices}")
    setattr(obj, name, value)


def material(name, color, metallic=0.0, emission=0.0):
    m = bpy.data.materials.new(name)
    m.use_nodes = True
    m.diffuse_color = (*color, 1)
    node = next(n for n in m.node_tree.nodes if n.type == 'BSDF_PRINCIPLED')
    node.inputs['Base Color'].default_value = (*color, 1)
    node.inputs['Metallic'].default_value = metallic
    node.inputs['Roughness'].default_value = 0.32
    node.inputs['Emission Color'].default_value = (*color, 1)
    node.inputs['Emission Strength'].default_value = emission
    return m, node


def box(name, location, scale, mat, bevel=0.08):
    bpy.ops.mesh.primitive_cube_add(size=1, location=location)
    ob = bpy.context.object
    ob.name = name
    ob.scale = scale
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    if bevel:
        mod = ob.modifiers.new('Rounded edges', 'BEVEL')
        mod.width = bevel
        mod.segments = 3
        ob.modifiers.new('Weighted corner normals', 'WEIGHTED_NORMAL')
    ob.data.materials.append(mat)
    return ob


def line(name, points, radius, mat, closed=False):
    curve = bpy.data.curves.new(name, 'CURVE')
    enum(curve, 'dimensions', '3D')
    curve.bevel_depth = radius
    curve.bevel_resolution = 3
    spline = curve.splines.new('POLY')
    spline.points.add(len(points)-1)
    for p, xyz in zip(spline.points, points):
        p.co = (*xyz, 1)
    spline.use_cyclic_u = closed
    ob = bpy.data.objects.new(name, curve)
    bpy.context.scene.collection.objects.link(ob)
    ob.data.materials.append(mat)
    return ob


def sphere(name, location, radius, mat):
    bpy.ops.mesh.primitive_uv_sphere_add(segments=20, ring_count=12, radius=radius, location=location)
    ob = bpy.context.object
    ob.name = name
    ob.data.materials.append(mat)
    for face in ob.data.polygons:
        face.use_smooth = True
    return ob


def label(body, location, size, mat):
    data = bpy.data.curves.new(body, 'FONT')
    data.body = body
    data.size = size
    data.extrude = 0.001
    ob = bpy.data.objects.new(body, data)
    bpy.context.scene.collection.objects.link(ob)
    ob.location = location
    ob.data.materials.append(mat)
    return ob


def sample(data, time, key):
    ts = data['time_s']
    j = min(max(bisect.bisect_right(ts, time), 1), len(ts)-1)
    a = (time-ts[j-1])/(ts[j]-ts[j-1])
    return data[key][j-1]*(1-a)+data[key][j]*a


def heat_color(rise, span):
    a = min(1.0, max(0.0, rise/span))
    cold, hot = (0.025, 0.25, 0.8), (1.0, 0.12, 0.015)
    return tuple((1-a)*c+a*h for c, h in zip(cold, hot))+(1,)


def animate_input(node, socket, value, frame):
    inp = node.inputs[socket]
    inp.default_value = value
    inp.keyframe_insert(data_path='default_value', frame=frame)


def build(payload, output, width, height):
    meta, data = payload['metadata'], payload['data']
    if meta['schema_version'] != 1:
        raise ValueError('Unsupported dataset schema')
    required = ['time_s', 'i_L_A', 'v_C_V', 'Phi_Wb', 'B_T', 'charge_C',
                'E_V_per_m', 'T_R_K', 'T_C_K', 'T_amb_K', 'source_V']
    ts = data['time_s']
    if len(ts) < 2 or any(b <= a for a, b in zip(ts, ts[1:])):
        raise ValueError('Time must contain at least two strictly increasing samples')
    for key in required:
        if len(data[key]) != len(ts) or not all(math.isfinite(x) for x in data[key]):
            raise ValueError(f'Invalid samples: {key}')
    # New scene preserves any input file's existing scenes.
    scene = bpy.data.scenes.new('RLC | coupled physics')
    bpy.context.window.scene = scene
    fps = int(meta['parameters']['fps'])
    count = round(fps*meta['parameters']['animation_seconds'])
    scene.frame_start, scene.frame_end = 1, count
    scene.render.fps = fps
    scene.render.resolution_x, scene.render.resolution_y = width, height
    scene.render.resolution_percentage = 100
    board, _ = material('Board | midnight', (0.014, 0.027, 0.045))
    white, _ = material('Typography | ivory', (0.78, 0.9, 1), emission=0.3)
    muted, _ = material('Typography | muted', (0.24, 0.46, 0.58), emission=0.1)
    copper, _ = material('Copper conductor', (0.64, 0.22, 0.075), metallic=0.8)
    metal, _ = material('Contacts | brushed silver', (0.35, 0.47, 0.55), metallic=0.8)
    resistor_mat, resistor_shader = material('Resistor temperature', (0.025, 0.25, 0.8))
    cap_thermal, cap_shader = material('Capacitor temperature', (0.025, 0.25, 0.8))
    electric_mat, electric_shader = material('Electric field | voltage magnitude', (0.02, 0.65, 1), emission=0)
    magnetic_mat, magnetic_shader = material('Magnetic flux | magnitude', (0.2, 0.9, 0.55), emission=0)
    source_mat, source_shader = material('Source pulse', (1, 0.47, 0.06), emission=0)
    bead_mat, _ = material('Flux tracer', (0.45, 1, 0.65), emission=3)
    box('Instrument board', (0, 0, -0.3), (17, 10, 0.5), board, 0.18)
    label('SERIES RLC', (-7.4, 3.5, 0.02), 0.65, white)
    label('ELECTRIC  /  MAGNETIC  /  THERMAL', (-7.35, 2.85, 0.02), 0.23, muted)
    p = meta['parameters']
    label(meta.get('source_description', 'Pulse source'), (3.3, 2.85, 0.02), 0.22, white)
    label(f"R {p['R']:g} ohm    L {p['L']:g} H    C {p['C']:g} F    Ambient {p['Tamb_C']:g} C",
          (-7.35, 2.35, 0.02), 0.22, white)
    # Series R-L-C and closed return path with source on the left.
    z = 0.9
    for index, points in enumerate([
            [(-7, -0.34, z), (-7, 0, z), (-5.55, 0, z)],
            [(-3.45, 0, z), (-1.6, 0, z), (-1.45, 0.53, z)],
            [(1.45, 0.53, z), (1.6, 0, z), (3.96, 0, z)],
            [(4.84, 0, z), (7, 0, z), (7, -1.65, z), (-7, -1.65, z), (-7, -1.30, z)]
    ]):
        line(f'Series conductor {index}', points, 0.045, copper)
    box('R | thermally active body', (-4.5, 0, z), (2.1, 0.65, 0.65), resistor_mat, 0.2)
    for x in [-5.6, -3.4]:
        box('R | terminal', (x, 0, z), (0.22, 0.67, 0.67), metal)
    # Helical conductor connects the two leads; no straight short through it.
    coil = []
    for k in range(801):
        u = k/800
        a = u*math.tau*9
        coil.append((-1.45+2.9*u, 0.53*math.cos(a), z+0.53*math.sin(a)))
    line('L | nine visible illustrative turns', coil, 0.065, copper)
    for x in [4.02, 4.78]:
        box('C | emissive electrode', (x, 0, z), (0.12, 1.25, 1.45), electric_mat, 0.04)
        box('C | thermal end cap', (x, 0, 0.12), (0.25, 1.45, 0.15), cap_thermal, 0.04)
    for y in [-0.42, 0, 0.42]:
        for zz in [z-0.43, z, z+0.43]:
            line('E | gap field', [(4.10, y, zz), (4.70, y, zz)], 0.017, electric_mat)
    sphere('Voltage source', (-7, -0.82, z), 0.48, source_mat)
    label('+', (-7.18, -0.95, 1.42), 0.4, white)
    label('VOLTAGE SOURCE',(-7.85,-2.10,.03),.16,white)
    tracers = []
    for k in range(5):
        angle = math.tau*k/5
        points = []
        for j in range(97):
            a = math.tau*j/96
            radial = 0.86*math.sin(a)
            points.append((1.9*math.cos(a), radial*math.cos(angle), z+radial*math.sin(angle)))
        line('B | illustrative closed flux line', points, 0.016, magnetic_mat, True)
        tracers.append((sphere('B | signed flux tracer', points[0], 0.065, bead_mat), angle))
    label('RESISTOR', (-5.75, -2.4, 0.02), 0.28, white)
    label('INDUCTOR', (-1.4, -2.4, 0.02), 0.28, white)
    label('CAPACITOR', (3.0, -2.4, 0.02), 0.28, white)
    label('Body color = temperature rise', (-6.3, -2.85, 0.02), 0.17, muted)
    label('Flux glow + tracer speed = |i|', (-2.2, -2.85, 0.02), 0.17, muted)
    label('Plate glow = |vC|; base = heat', (2.7, -2.85, 0.02), 0.17, muted)
    label(f"Blue: ambient   Orange: +{meta['temperature_span_K']:g} K", (-7.35, -3.55, 0.02), 0.21, white)
    label(f"Physical time: {ts[0]:g} to {ts[-1]:g} s  |  Field geometry illustrative", (-7.35, -4.05, 0.02), 0.20, muted)
    label(f"Peak |vC| {max(map(abs, data['v_C_V'])):.2f} V   |i| {max(map(abs, data['i_L_A'])):.2f} A   |B| {max(map(abs, data['B_T'])):.3f} T",
          (-7.35, -4.5, 0.02), 0.19, white)
    progress = sphere('Time cursor', (-7.3, -4.8, 0.03), 0.055, bead_mat)
    line('Time rail', [(-7.3, -4.8, 0.03), (7.3, -4.8, 0.03)], 0.012, muted)
    phase = 0
    for frame in range(1, count+1):
        time = ts[0]+(ts[-1]-ts[0])*(frame-1)/(count-1)
        current = sample(data, time, 'i_L_A')
        voltage = sample(data, time, 'v_C_V')
        ambient = sample(data, time, 'T_amb_K')
        for shader, field in [(resistor_shader, 'T_R_K'), (cap_shader, 'T_C_K')]:
            color = heat_color(sample(data, time, field)-ambient, meta['temperature_span_K'])
            animate_input(shader, 'Base Color', color, frame)
        strength_v = min(abs(voltage)/meta['voltage_scale_V'], 2)
        strength_i = min(abs(current)/meta['current_scale_A'], 2)
        animate_input(electric_shader, 'Emission Strength', 3*strength_v, frame)
        sign_color = (0.02, 0.65, 1, 1) if voltage >= 0 else (1, 0.22, 0.06, 1)
        animate_input(electric_shader, 'Emission Color', sign_color, frame)
        animate_input(magnetic_shader, 'Emission Strength', 5*strength_i, frame)
        animate_input(source_shader, 'Emission Strength', 2*abs(sample(data, time, 'source_V'))/meta['voltage_scale_V'], frame)
        if frame > 1:
            phase += math.tau*2.0*current/meta['current_scale_A']/fps
        for ob, angle in tracers:
            a = phase+angle
            radial = 0.86*math.sin(a)
            ob.location = (1.9*math.cos(a), radial*math.cos(angle), z+radial*math.sin(angle))
            ob.scale = (max(strength_i, 0.001)**0.5,)*3
            ob.keyframe_insert(data_path='location', frame=frame)
            ob.keyframe_insert(data_path='scale', frame=frame)
        progress.location.x = -7.3+14.6*(frame-1)/(count-1)
        progress.keyframe_insert(data_path='location', frame=frame)
    # Linear interpolation prevents Bezier overshoot between measured samples.
    for action in bpy.data.actions:
        if hasattr(action, 'layers'):
            for layer in action.layers:
                for strip in layer.strips:
                    for bag in strip.channelbags:
                        for fc in bag.fcurves:
                            for key in fc.keyframe_points:
                                enum(key, 'interpolation', 'LINEAR')
        elif hasattr(action, 'fcurves'):
            for fc in action.fcurves:
                for key in fc.keyframe_points:
                    enum(key, 'interpolation', 'LINEAR')
    world = bpy.data.worlds.new('Studio environment')
    scene.world = world
    world.use_nodes = True
    background = next(n for n in world.node_tree.nodes if n.type == 'BACKGROUND')
    background.inputs['Color'].default_value = (0.04, 0.065, 0.1, 1)
    background.inputs['Strength'].default_value = 0.45
    for loc, energy, size in [((0, -2, 12), 1800, 9), ((2, 6, 8), 1400, 7)]:
        bpy.ops.object.light_add(type='AREA', location=loc)
        ob = bpy.context.object
        ob.data.energy, ob.data.size = energy, size
        ob.rotation_euler = (-ob.location).to_track_quat('-Z', 'Y').to_euler()
    bpy.ops.object.camera_add(location=(1, -13, 18))
    camera = bpy.context.object
    enum(camera.data, 'type', 'ORTHO')
    camera.data.ortho_scale = 19.7
    camera.rotation_euler = (Vector((0, -0.2, 0))-camera.location).to_track_quat('-Z', 'Y').to_euler()
    scene.camera = camera
    # The saved animation plays without Python auto-run being enabled.
    scene.frame_set(1)
    if hasattr(scene.render.image_settings, 'media_type'):
        enum(scene.render.image_settings, 'media_type', 'VIDEO')
    enum(scene.render.image_settings, 'file_format', 'FFMPEG')
    enum(scene.render.ffmpeg, 'format', 'MPEG4')
    enum(scene.render.ffmpeg, 'codec', 'H264')
    scene.render.filepath = str(output/'rlc_animation.mp4')
    bpy.ops.wm.save_as_mainfile(filepath=str(output/'rlc_animation.blend'))
    return scene, count


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--data', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--render', action='store_true')
    parser.add_argument('--width', type=int, default=1280)
    parser.add_argument('--height', type=int, default=720)
    argv = sys.argv[sys.argv.index('--')+1:] if '--' in sys.argv else []
    args = parser.parse_args(argv)
    args.data = args.data.resolve()
    args.output = args.output.resolve()
    args.output.mkdir(parents=True, exist_ok=True)
    status = args.output/'blender_status.json'
    publish(args.output, 'building')
    try:
        payload = json.loads(args.data.read_text(encoding='utf-8'))
        scene, count = build(payload, args.output, args.width, args.height)
        # Representative late-run pulse: warm bodies and active electrical fields.
        p = payload['metadata']['parameters']
        preview_t = max(0, p['stop_s']-p['period_s']+0.06)
        preview_frame = min(count, 1+round(preview_t/p['stop_s']*(count-1)))
        scene.frame_set(preview_frame)
        if hasattr(scene.render.image_settings, 'media_type'):
            enum(scene.render.image_settings, 'media_type', 'IMAGE')
        enum(scene.render.image_settings, 'file_format', 'PNG')
        scene.render.filepath = str(args.output/'rlc_preview.png')
        publish(args.output, 'previews', completed=0, total=1)
        bpy.ops.render.render(write_still=True)
        if args.render:
            if hasattr(scene.render.image_settings, 'media_type'):
                enum(scene.render.image_settings, 'media_type', 'VIDEO')
            enum(scene.render.image_settings, 'file_format', 'FFMPEG')
            scene.render.filepath = str(args.output/'rlc_animation.mp4')
            render_animation(scene, args.output)
        status.write_text(json.dumps({'state': 'complete', 'frames': count,
                                      'rendered': args.render, 'source': str(args.data.resolve())}, indent=2))
        print('RLC_WORKFLOW_COMPLETE', flush=True)
    except Exception as exc:
        status.write_text(json.dumps({'state': 'failed', 'message': str(exc)}))
        traceback.print_exc()
        raise


if __name__ == '__main__':
    main()

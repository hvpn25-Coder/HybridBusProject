"""Presentation renderer: studio assembly, domain close-ups and baked telemetry.
All physical magnitudes come from the exported simulation dataset. Spatial field
curves are explanatory geometry, not FEM. No runtime handlers or extra packages.
"""
import argparse
import csv
import hashlib
import json
import math
import sys
import traceback
from pathlib import Path

import bpy
from mathutils import Vector

sys.path.insert(0, str(Path(__file__).parent))
from rlc_visualize import enum, material, box, line, sphere, label, sample, animate_input
from render_progress import publish, render_animation
from engineering_overlay import EngineeringOverlay


def emissive(name, color, strength=1):
    mat = bpy.data.materials.new(name)
    mat.use_nodes = True
    nodes = mat.node_tree.nodes
    nodes.clear()
    output = nodes.new('ShaderNodeOutputMaterial')
    shader = nodes.new('ShaderNodeEmission')
    shader.inputs['Color'].default_value = (*color, 1)
    shader.inputs['Strength'].default_value = strength
    mat.node_tree.links.new(shader.outputs[0], output.inputs['Surface'])
    return mat, shader


def cylinder(name, center, radius, length, mat, axis=(1, 0, 0)):
    bpy.ops.mesh.primitive_cylinder_add(vertices=64, radius=radius, depth=length, location=center)
    ob = bpy.context.object
    ob.name = name
    ob.rotation_euler = Vector(axis).to_track_quat('Z', 'Y').to_euler()
    ob.data.materials.append(mat)
    bevel = ob.modifiers.new('Machined edge', 'BEVEL')
    bevel.width, bevel.segments = 0.045, 3
    ob.modifiers.new('Corner normals', 'WEIGHTED_NORMAL')
    for face in ob.data.polygons:
        face.use_smooth = True
    return ob


def color_map(value):
    palette = [(0.018, .12, .70), (.01, .65, .86), (.12, .8, .44),
               (.95, .8, .05), (1, .22, .015), (.8, .025, .008)]
    u = min(max(value, 0), 1)*(len(palette)-1)
    k = min(int(u), len(palette)-2)
    f = u-k
    return tuple(a*(1-f)+b*f for a, b in zip(palette[k], palette[k+1]))+(1,)


class Screen:
    """Camera-space vector graphics: sharp and fully saved in the blend file."""
    def __init__(self, camera, aspect):
        self.camera = camera
        self.w = camera.data.sensor_width/camera.data.lens
        self.h = self.w/aspect
        self.root = bpy.data.objects.new('Presentation graphics', None)
        bpy.context.scene.collection.objects.link(self.root)
        self.root.parent = camera
        self.root.location.z = -1
        self.objects = []
        self.font = None
        self.bold = None
        for name, attr in [('segoeui.ttf', 'font'), ('segoeuib.ttf', 'bold')]:
            p = Path('C:/Windows/Fonts')/name
            if p.exists():
                setattr(self, attr, bpy.data.fonts.load(str(p)))

    def xy(self, x, y, z=0):
        return ((x-.5)*self.w, (y-.5)*self.h, z)

    def attach(self, ob):
        ob.parent = self.root
        if hasattr(ob, 'visible_shadow'):
            ob.visible_shadow = False
        self.objects.append(ob)
        return ob

    def text(self, text, x, y, size, mat, bold=False):
        data = bpy.data.curves.new('Type | '+text, 'FONT')
        data.body = text
        data.size = self.h*size
        if self.font:
            data.font = self.bold if bold and self.bold else self.font
        ob = bpy.data.objects.new(text, data)
        bpy.context.scene.collection.objects.link(ob)
        ob.location = self.xy(x, y, .001)
        ob.data.materials.append(mat)
        return self.attach(ob)

    def rect(self, name, x, y, w, h, mat, z=-.001):
        mesh = bpy.data.meshes.new(name)
        mesh.from_pydata([self.xy(x, y, z), self.xy(x+w, y, z),
                          self.xy(x+w, y+h, z), self.xy(x, y+h, z)], [], [(0, 1, 2, 3)])
        ob = bpy.data.objects.new(name, mesh)
        bpy.context.scene.collection.objects.link(ob)
        ob.data.materials.append(mat)
        return self.attach(ob)

    def curve(self, name, points, mat, thickness=.001):
        ob = line(name, [self.xy(x, y, .001) for x, y in points], self.h*thickness, mat)
        return self.attach(ob)


class Number:
    """Bake numeric readouts as glyph visibility keys; no Python auto-run needed."""
    def __init__(self, screen, x, y, size, mat, length=8):
        self.slots = []
        self.previous = [' ']*length
        for j in range(length):
            glyphs = {}
            for char in '0123456789.e-+':
                ob = screen.text(char, x+j*size*.32, y, size, mat)
                ob.hide_render = True
                ob.hide_viewport = True
                ob.keyframe_insert(data_path='hide_render', frame=1)
                ob.keyframe_insert(data_path='hide_viewport', frame=1)
                glyphs[char] = ob
            self.slots.append(glyphs)

    def set(self, text, frame):
        if len(text)>len(self.slots):
            text=f'{float(text):+.1e}'
        if len(text)>len(self.slots):
            text=f'{float(text):+.0e}'
        text = text.rjust(len(self.slots))[-len(self.slots):]
        for j, char in enumerate(text):
            if char == self.previous[j]:
                continue
            for c, hidden in [(self.previous[j], True), (char, False)]:
                if c in self.slots[j]:
                    ob = self.slots[j][c]
                    ob.hide_render = hidden
                    ob.hide_viewport = hidden
                    ob.keyframe_insert(data_path='hide_render', frame=frame)
                    ob.keyframe_insert(data_path='hide_viewport', frame=frame)
            self.previous[j] = char


def visibility(objects, start, end, total):
    for ob in objects:
        for frame, hide in [(1, start > 1), (start, False), (end+1, True)]:
            if frame > total:
                continue
            ob.hide_render = hide
            ob.hide_viewport = hide
            ob.keyframe_insert(data_path='hide_render', frame=frame)
            ob.keyframe_insert(data_path='hide_viewport', frame=frame)


def key_material(node, name, value, frame):
    node.inputs[name].default_value = value
    node.inputs[name].keyframe_insert(data_path='default_value', frame=frame)


def time_windows(p, ts):
    mode = p.get('source_mode', 3)
    if mode == 2:
        window = min(ts[-1]-ts[0], 2/p.get('frequency_Hz', 60))
        start = max(ts[0], ts[-1]-window)
    elif mode == 1:
        start, window = ts[0], min(ts[-1]-ts[0], 8*math.sqrt(p['L']*p['C']))
    else:
        window = min(ts[-1]-ts[0], p['period_s'])
        start = max(ts[0], ts[-1]-window)
    return [(start, start+window), (start, start+window), (start, start+window),
            (ts[0], ts[-1]), (ts[-1], ts[-1])]


def build(payload, output, width=1920, height=1080, seconds=26):
    meta, data = payload['metadata'], payload['data']
    p, ts = meta['parameters'], data['time_s']
    for field in ['i_L_A','v_C_V','Phi_Wb','T_R_K','T_C_K','T_amb_K','source_V']:
        if len(data[field]) != len(ts) or not all(math.isfinite(x) for x in data[field]):
            raise ValueError('Invalid field '+field)
    if any(b <= a for a, b in zip(ts, ts[1:])):
        raise ValueError('Time samples must be strictly increasing')
    scene = bpy.data.scenes.new('RLC | executive presentation')
    bpy.context.window.scene = scene
    fps = 24
    total = round(seconds*fps)
    scene.frame_start, scene.frame_end, scene.render.fps = 1, total, fps
    scene.render.resolution_x, scene.render.resolution_y = width, height
    scene.render.resolution_percentage = 100
    scene.eevee.taa_render_samples = 48
    scene.eevee.use_fast_gi = True
    return scene


def populate(scene, payload, output, seconds):
    meta, data = payload['metadata'], payload['data']
    p, ts = meta['parameters'], data['time_s']
    total, fps = scene.frame_end, scene.render.fps
    bounds = [1, round(total*4/26)+1, round(total*10/26)+1,
              round(total*16/26)+1, round(total*22/26)+1, total+1]
    windows = time_windows(p, ts)
    copper, _ = material('Satin copper', (.72, .29, .105), .88)
    silver, _ = material('Machined aluminium', (.42, .50, .61), .85)
    ceramic, rshader = material('Alumina | thermal body', (.68, .70, .64), .08)
    capmetal, cshader = material('Capacitor electrodes', (.38, .48, .61), .78)
    ferrite, _ = material('Ferrite', (.018, .022, .028), .25)
    plastic, _ = material('Black polymer', (.018, .025, .035), .12)
    nichrome, _ = material('Resistance wire', (.14, .15, .16), .75)
    ground, _ = material('Studio graphite', (.012, .019, .029), .30)
    white, _ = emissive('UI white', (.78, .87, .97))
    muted, _ = emissive('UI secondary', (.26, .39, .53))
    cyan, _ = emissive('Electric cyan', (.015, .57, .95), 1.3)
    amber, _ = emissive('Thermal amber', (1, .37, .055), 1.2)
    mint, _ = emissive('Magnetic mint', (.12, .9, .6), 1.3)
    panel, _ = emissive('UI panel', (.009, .016, .027))
    rule, _ = emissive('UI divider', (.035, .065, .10))
    electric, eshader = emissive('Dielectric field', (.02, .6, 1), 0)
    field_mats = [emissive('Flux '+str(k), c, 0) for k, c in enumerate([
        (.02, .12, .75), (.015, .65, .85), (.12, .95, .58), (.85, 1, .24)])]
    tracer, _ = emissive('Field tracers', (.45, 1, .82), 2)
    # Microtexture provides highlights without distracting surface decoration.
    for mat in [copper, silver, capmetal]:
        shader = next(n for n in mat.node_tree.nodes if n.type == 'BSDF_PRINCIPLED')
        noise = mat.node_tree.nodes.new('ShaderNodeTexNoise')
        noise.inputs['Scale'].default_value = 150
        bump = mat.node_tree.nodes.new('ShaderNodeBump')
        bump.inputs['Strength'].default_value = .12
        bump.inputs['Distance'].default_value = .012
        mat.node_tree.links.new(noise.outputs['Fac'], bump.inputs['Height'])
        mat.node_tree.links.new(bump.outputs['Normal'], shader.inputs['Normal'])
    box('Infinite studio floor', (0, 0, -.5), (200, 200, .3), ground, 0)
    z = 1.35
    for x, name in [(-4.5, 'R'), (0, 'L'), (4.5, 'C')]:
        box(name+' | pedestal', (x, 0, -.11), (3.8, 3.0, .45), plastic, .18)
        box(name+' | inset top', (x, 0, .14), (3.55, 2.75, .08), ferrite, .08)
        line(name+' | illuminated reveal', [(x-1.6,-1.4,-.02),(x+1.6,-1.4,-.02)], .012, cyan)
        for xx in [x-1.52, x+1.52]:
            for yy in [-1.1, 1.1]:
                cylinder('Recessed fastener', (xx, yy, .20), .065, .035, silver, (0,0,1))
                line('Fastener slot', [(xx-.04,yy,.222),(xx+.04,yy,.222)], .009, ferrite)
    # Wirewound resistor with ceramic former, end caps, wire and standoffs.
    cylinder('R | alumina former', (-4.5,0,z), .49, 2.15, ceramic)
    wind = [(-5.48+1.96*j/800,.505*math.cos(j/800*math.tau*24),
             z+.505*math.sin(j/800*math.tau*24)) for j in range(801)]
    line('R | resistance winding', wind, .014, nichrome)
    for x in [-5.64,-3.36]:
        cylinder('R | metal cap', (x,0,z), .53, .22, silver)
        cylinder('R | support', (x,0,.66), .12, .90, ceramic, (0,0,1))
    # Polished continuous helical conductor around a matte core.
    cylinder('L | core', (0,0,z), .38, 3.5, ferrite)
    for x in [-1.56,1.56]:
        cylinder('L | end cheek', (x,0,z), .88, .10, plastic)
        box('L | support shoe', (x,0,.52), (.25,1,.65), plastic)
    coil = [(-1.4+2.8*j/1000,.76*math.cos(j/1000*math.tau*9),
             z+.76*math.sin(j/1000*math.tau*9)) for j in range(1001)]
    line('L | copper helix', coil, .09, copper)
    # Exploded parallel-plate capacitor: the visible gap is a schematic cutaway.
    for x in [4.03,4.97]:
        box('C | aluminium plate', (x,0,z), (.10,1.7,1.9), capmetal, .04)
        box('C | insulating foot', (x,0,.29), (.32,1.95,.15), ceramic, .07)
        for y in [-.65,.65]:
            cylinder('C | ceramic tie', (4.5,y,.48), .07, 1.35, ceramic)
            for xx in [3.87,5.13]:
                cylinder('C | terminal nut', (xx,y,.48), .11, .07, silver)
    # Visible foreground supply with separate positive and return leads.
    source_before=set(scene.objects)
    mode=p.get('source_mode',3)
    source_type={1:'DC',2:f"AC {p.get('frequency_Hz',60):g} Hz",3:'PULSE'}[mode]
    rating=f"{p['voltage_V']:g} V"+(' RMS' if mode==2 else '')
    supply_metal,_=material('Source | brushed enclosure',(.12,.18,.24),.65)
    positive,_=material('Source | positive insulation',(.48,.018,.012),.12)
    negative,_=material('Source | return insulation',(.018,.07,.22),.12)
    supply_glow,supply_shader=emissive('Source | live output indicator',(.02,.75,1),1)
    box('Voltage source | power supply',(0,-2.8,.65),(3.0,1.2,1.65),supply_metal,.12)
    box('Voltage source | front panel',(0,-3.415,.65),(2.8,.035,1.4),plastic,.04)
    box('Voltage source | display',(0,-3.442,.77),(1.66,.02,.52),panel,.025)
    def source_label(text,x,z,size,mat=white):
        ob=label(text,(x,-3.465,z),size,mat)
        ob.rotation_euler=(math.pi/2,0,0)
        return ob
    source_label('VOLTAGE SOURCE',-1.22,1.13,.22)
    source_label(source_type+' / '+rating,-.77,.87,.15,cyan)
    source_label('+',-1.17,.93,.23,amber)
    source_label('-',1.01,.93,.23,cyan)
    for x,mat in [(-1.08,positive),(1.08,negative)]:
        cylinder('Source | output terminal',(x,-3.48,.67),.12,.17,mat,(0,1,0))
        cylinder('Source | metal contact',(x,-3.59,.67),.055,.08,silver,(0,1,0))
    sphere('Source | output active LED',(-.68,-3.47,.42),.045,supply_glow)
    source_label('OUTPUT',-.55,.36,.13)
    # Static waveform symbol identifies the selected excitation; the LED and HUD
    # use the actual logged source voltage at each animation frame.
    if mode==2:
        wave=[(-.7+1.4*j/64,-3.47,.64+.10*math.sin(math.tau*j/64)) for j in range(65)]
    elif mode==3:
        wave=[(-.7,-3.47,.55),(-.4,-3.47,.55),(-.4,-3.47,.73),(.1,-3.47,.73),(.1,-3.47,.55),(.7,-3.47,.55)]
    else:
        wave=[(-.7,-3.47,.65),(.7,-3.47,.65)]
    line('Source | waveform symbol',wave,.012,cyan)
    source_objects=[ob for ob in scene.objects if ob not in source_before]
    # Electrical connections have no short circuit across any component.
    for points in [
        [(-6.5,0,z),(-5.8,0,z)], [(-3.2,0,z),(-1.65,0,z),(-1.4,.76,z)],
        [(1.4,.76,z),(1.65,0,z),(3.97,0,z)],
        [(5.03,0,z),(6.5,0,z)]]:
        line('Series bus', points, .045, copper)
    line('Source | positive lead',[(-1.08,-3.64,.67),(-1.08,-3.85,.44),(-6.5,-3.85,.44),(-6.5,0,z)],.045,positive)
    line('Source | return lead',[(6.5,0,z),(6.5,-3.85,.44),(1.08,-3.85,.44),(1.08,-3.64,.67)],.045,negative)
    # Dense, layered explanatory magnetic curves with bright near-core sections.
    field_objects, particles = [], []
    def field_point(a, angle, layer):
        radial = .07+.10*layer+(1.1+.18*layer)*(1-math.cos(a))/2
        return Vector(((2.25+.20*layer)*math.sin(a),radial*math.cos(angle),z+radial*math.sin(angle)))
    for layer in range(3):
        for ring in range(8):
            angle = math.tau*ring/8
            for sector in range(8):
                pts = [field_point(math.tau*(sector+j/16)/8,angle,layer) for j in range(17)]
                rank = 3 if sector in (0,7) else 2 if sector in (1,6) else 1 if sector in (2,5) else 0
                field_objects.append(line('Magnetic streamline', pts, .009 if layer else .012,field_mats[rank][0]))
            ob = sphere('Magnetic direction tracer', field_point(0,angle,layer), .028, tracer)
            particles.append((ob,angle,layer))
    # Electric field arrows and carrier-like markers illustrate polarity, not drift.
    arrows, electric_lines = [], []
    for y in [-.60,-.30,0,.30,.60]:
        for zz in [z-.66,z-.33,z,z+.33,z+.66]:
            electric_lines.append(line('Electric gap vector',[(4.10,y,zz),(4.90,y,zz)],.009,electric))
            bpy.ops.mesh.primitive_cone_add(vertices=12,radius1=.027,radius2=0,depth=.10,location=(4.5,y,zz))
            ob=bpy.context.object; ob.name='Electric polarity arrow'
            ob.data.materials.append(electric); arrows.append(ob)
    # Studio: key, copper rim, and cool fill with large reflection sources.
    world = bpy.data.worlds.new('Dark photographic studio'); scene.world=world; world.use_nodes=True
    bg=next(n for n in world.node_tree.nodes if n.type=='BACKGROUND')
    bg.inputs['Color'].default_value=(.045,.065,.10,1); bg.inputs['Strength'].default_value=.35
    for pos,energy,size,color in [((-3,-5,9),1900,7,(.76,.86,1)),((1,5,7),2400,5,(1,.62,.31)),
                                   ((8,-2,6),1400,5,(.35,.66,1)),((-9,1,4),1100,4,(.4,.7,1))]:
        bpy.ops.object.light_add(type='AREA',location=pos)
        ob=bpy.context.object; ob.data.energy=energy; ob.data.size=size; ob.data.color=color
        ob.rotation_euler=(Vector((0,0,1))-ob.location).to_track_quat('-Z','Y').to_euler()
    bpy.ops.object.camera_add()
    camera=bpy.context.object; camera.name='Presentation camera'; camera.data.lens=45
    camera.data.clip_start=.05; scene.camera=camera
    screen=Screen(camera,scene.render.resolution_x/scene.render.resolution_y)
    screen.rect('Telemetry panel',.68,.16,.28,.69,panel)
    screen.rect('Accent',.68,.83,.28,.003,cyan)
    screen.text('SIMULATION TELEMETRY',.70,.79,.019,muted,True)
    labels=[('SOURCE VOLTAGE','V',.73,cyan),('CURRENT','A',.63,mint),('CAPACITOR VOLTAGE','V',.53,cyan),
            ('FLUX PER TURN','mWb',.43,mint),('RESISTOR','deg C',.34,amber),('CAPACITOR','deg C',.27,amber)]
    numbers=[]
    for title,unit,y,mat in labels:
        screen.text(title,.70,y+.018,.014,muted,True)
        numbers.append(Number(screen,.705,y-.022,.036,mat))
        screen.text(unit,.90,y-.016,.017,muted)
    screen.text('PHYSICAL TIME',.70,.22,.014,muted,True)
    clock=Number(screen,.705,.18,.038,white)
    screen.text('s',.91,.186,.017,muted)
    screen.text('SERIES RLC  /  ENGINEERING REVIEW',.05,.942,.018,muted,True)
    source=meta.get('source_description','Pulse source')
    screen.text(f"{source}  |  R {p['R']:g} ohm  ·  L {p['L']:g} H  ·  C {p['C']:g} F",.05,.036,.017,muted)
    engine='Basic Simulink' if meta.get('model_backend')=='basic' else 'Simscape'
    screen.text(f'{engine} results · spatial field geometry illustrative',.57,.036,.013,muted)
    screen.rect('Playback rail',.05,.075,.91,.0018,rule)
    progress=screen.rect('Playback indicator',.05,.073,.004,.006,cyan,.002)
    engineering=EngineeringOverlay(screen,Number,data,p,(white,muted,cyan,amber,mint,panel,rule))
    chapters=[('01 / SYSTEM OVERVIEW','Energy in motion.', 'One electrical path. Three coupled domains.'),
              ('02 / MAGNETIC ENERGY','Current becomes flux.', 'The coil stores energy in its magnetic field.'),
              ('03 / ELECTRIC ENERGY','Charge creates a field.', 'Voltage builds across the capacitor dielectric.'),
              ('04 / THERMAL RESPONSE','Losses become heat.', 'Temperature feeds back into resistance and ESR.'),
              ('05 / ENGINEERING INSIGHT','One connected model.', 'Electrical response, field energy and thermal feedback.')]
    cursors=[]
    for k,(eyebrow,title,insight) in enumerate(chapters):
        first=len(screen.objects)
        screen.text(eyebrow,.05,.878,.020,cyan,True)
        screen.text(title,.048,.810,.060,white,True)
        # Bottom strip now carries quantitative power/energy instead of prose.
        t0,t1=windows[k]
        speed=(t1-t0)/max((bounds[k+1]-bounds[k])/fps,1/fps)
        time_note='FINAL STATE' if k==4 else f"PHYSICAL TIME {t0:.4g}–{t1:.4g} s  /  " + (f"{1/speed:.0f}x SLOW MOTION" if 0<speed<1 else f"{speed:.2g}x PLAYBACK")
        screen.text(time_note,.05,.772,.016,muted)
        # Waveform inset for the domain close-ups; a trace with an animated cursor.
        if k in (1,2,3):
            x0,x1,y0,y1=.05,.32,.21,.34
            screen.rect('Trace card',x0-.01,y0-.025,x1-x0+.025,y1-y0+.075,panel)
            key='i_L_A' if k==1 else 'v_C_V' if k==2 else 'T_R_K'
            title='CURRENT / A' if k==1 else 'VOLTAGE / V' if k==2 else 'TEMPERATURE RISE / K'
            vals=[sample(data,t0+(t1-t0)*j/300,key) for j in range(301)]
            if k==3:
                vals=[v-sample(data,t0+(t1-t0)*j/300,'T_amb_K') for j,v in enumerate(vals)]
            maximum=max(max(map(abs,vals)),1e-6)
            low=0 if k==3 else -maximum
            high=max(maximum,1e-6)
            screen.text(title,x0,y1+.025,.014,muted,True)
            screen.text(f"{high:.3g}",x1-.035,y1+.025,.014,muted)
            for j in range(3):
                screen.curve('Trace grid',[(x0,y0+(y1-y0)*j/2),(x1,y0+(y1-y0)*j/2)],rule,.0005)
            screen.curve('Measured response',[(x0+(x1-x0)*j/300,y0+(y1-y0)*(v-low)/(high-low)) for j,v in enumerate(vals)],amber if k==3 else mint if k==1 else cyan,.0012)
            cursor=screen.curve('Sample cursor',[(x0,y0),(x0,y1)],white,.0007)
            cursors.append((k,cursor,x0,x1))
        if k==3:
            for j in range(30):
                m,_=emissive('Thermal legend '+str(j),color_map(j/29)[:3])
                screen.rect('Temperature scale',.38+j*.008,.245,.008,.012,m)
            screen.text('FALSE COLOR / RISE ABOVE AMBIENT',.38,.278,.012,muted,True)
            screen.text('0 K',.38,.218,.015,muted)
            screen.text(f"+{meta['temperature_span_K']:g} K",.56,.218,.015,muted)
        if k==4:
            dr=data['T_R_K'][-1]-data['T_amb_K'][-1]
            dc=data['T_C_K'][-1]-data['T_amb_K'][-1]
            screen.text(f"{max(map(abs,data['i_L_A'])):.2f} A peak     {max(map(abs,data['v_C_V'])):.2f} V peak",.05,.27,.030,white)
            screen.text(f"Final rise: resistor +{dr:.3f} K  /  capacitor +{dc:.3f} K",.05,.22,.022,amber)
        visibility(screen.objects[first:],bounds[k],bounds[k+1]-1,total)
    # Bake every result and camera frame. Replay clocks are explicit in each shot.
    frame_map=[]
    imax=max(max(map(abs,data['i_L_A'])),1e-9)
    vmax=max(max(map(abs,data['v_C_V'])),1e-9)
    phase=0
    for f in range(1,total+1):
        k=max(j for j in range(5) if f>=bounds[j])
        u=(f-bounds[k])/max(bounds[k+1]-bounds[k]-1,1)
        ease=u*u*(3-2*u)
        t0,t1=windows[k]; t=t0+(t1-t0)*u
        current=sample(data,t,'i_L_A'); voltage=sample(data,t,'v_C_V')
        source_voltage=sample(data,t,'source_V')
        key_material(supply_shader,'Strength',.15+2*abs(source_voltage)/max(abs(p['voltage_V']),1e-9),f)
        phi=sample(data,t,'Phi_Wb'); tr=sample(data,t,'T_R_K'); tc=sample(data,t,'T_C_K')
        ambient=sample(data,t,'T_amb_K')
        for display,value,fmt in zip(numbers,[source_voltage,current,voltage,phi*1000,tr-273.15,tc-273.15],['+.2f','+.3f','+.2f','+.3f','.2f','.2f']):
            display.set(format(value,fmt),f)
        clock.set(f'{t:.4f}',f)
        engineering.update(t,f)
        if k in (0,3,4):
            target=Vector((0,0,1.1))
            offset=Vector((7-2*ease,-26+ease,14.5-.5*ease))
        elif k==1:
            target=Vector((0,0,z))
            offset=Vector((2.5-1.1*ease,-10.8,5.2+.4*ease))
        else:
            target=Vector((4.5,0,z))
            offset=Vector((3.2-.6*ease,-7.8,4.2))
        camera.location=target+offset
        camera.rotation_euler=(target-camera.location).to_track_quat('-Z','Y').to_euler()
        camera.data.shift_x=.17
        camera.keyframe_insert(data_path='location',frame=f)
        camera.keyframe_insert(data_path='rotation_euler',frame=f)
        screen.root.location.x=camera.data.shift_x*screen.w
        for ob in source_objects:
            ob.hide_render=k in (1,2)
            ob.hide_viewport=ob.hide_render
            ob.keyframe_insert(data_path='hide_render',frame=f)
            ob.keyframe_insert(data_path='hide_viewport',frame=f)
        v=abs(voltage)/vmax; a=abs(current)/imax
        field_on=1 if k==1 else .35 if k==0 else 0
        for rank,(_,shader) in enumerate(field_mats):
            key_material(shader,'Strength',(.65+(3+rank*1.2)*a)*field_on,f)
        for ob in field_objects:
            ob.hide_render=k not in (0,1)
            ob.hide_viewport=ob.hide_render
            ob.keyframe_insert(data_path='hide_render',frame=f)
            ob.keyframe_insert(data_path='hide_viewport',frame=f)
        for ob in electric_lines+arrows:
            ob.hide_render=k not in (0,2)
            ob.hide_viewport=ob.hide_render
            ob.keyframe_insert(data_path='hide_render',frame=f)
            ob.keyframe_insert(data_path='hide_viewport',frame=f)
        key_material(eshader,'Strength',3.2*v if k in (0,2) else 0,f)
        key_material(eshader,'Color',(.02,.7,1,1) if voltage>=0 else (1,.24,.05,1),f)
        phase+=math.tau*1.7*current/imax/fps
        for ob,angle,layer in particles:
            ob.location=field_point(phase+angle,angle,layer)
            ob.scale=(max(a*field_on,.00001)**.5,)*3
            ob.keyframe_insert(data_path='location',frame=f)
            ob.keyframe_insert(data_path='scale',frame=f)
        for ob in arrows:
            ob.rotation_euler=Vector((1 if voltage>=0 else -1,0,0)).to_track_quat('Z','Y').to_euler()
            ob.keyframe_insert(data_path='rotation_euler',frame=f)
        rcolor=color_map((tr-ambient)/meta['temperature_span_K']) if k==3 else (.68,.70,.64,1)
        ccolor=color_map((tc-ambient)/meta['temperature_span_K']) if k==3 else (.38,.48,.61,1)
        animate_input(rshader,'Base Color',rcolor,f)
        animate_input(cshader,'Base Color',ccolor,f)
        animate_input(cshader,'Emission Color',(.02,.5,.9,1),f)
        animate_input(cshader,'Emission Strength',.8*v if k==2 else 0,f)
        progress.location.x=.91*(f-1)/(total-1)*screen.w
        progress.keyframe_insert(data_path='location',frame=f)
        for chapter,cursor,x0,x1 in cursors:
            if chapter==k:
                cursor.location.x=(x1-x0)*u*screen.w
                cursor.keyframe_insert(data_path='location',frame=f)
        frame_map.append((f,(f-1)/fps,k+1,t,current,voltage,tr,tc,source_voltage))
    for action in bpy.data.actions:
        for layer in action.layers:
            for strip in layer.strips:
                for bag in strip.channelbags:
                    for fc in bag.fcurves:
                        for point in fc.keyframe_points:
                            enum(point,'interpolation','CONSTANT' if 'hide_' in fc.data_path else 'LINEAR')
    with (output/'frame_mapping.csv').open('w',newline='') as stream:
        writer=csv.writer(stream)
        writer.writerow(['frame','video_time_s','chapter','physical_time_s','i_A','vC_V','TR_K','TC_K','source_V'])
        writer.writerows(frame_map)
    # Subtle optical glow; typography is kept under the glare threshold.
    tree=bpy.data.node_groups.new('Presentation optical finish','CompositorNodeTree')
    tree.interface.new_socket(name='Image',in_out='OUTPUT',socket_type='NodeSocketColor')
    render=tree.nodes.new('CompositorNodeRLayers'); render.scene=scene
    glare=tree.nodes.new('CompositorNodeGlare')
    glare.inputs['Type'].default_value='Fog Glow'
    if 'Threshold' in glare.inputs: glare.inputs['Threshold'].default_value=1.8
    final=tree.nodes.new('NodeGroupOutput')
    tree.links.new(render.outputs['Image'],glare.inputs['Image']); tree.links.new(glare.outputs['Image'],final.inputs['Image'])
    scene.compositing_node_group=tree
    scene['model_scope']='Lumped electrical/thermal model; field geometry illustrative; no spatial FEM'
    scene['presentation_seconds']=seconds
    scene.frame_set(1)
    enum(scene.render.image_settings,'media_type','VIDEO')
    enum(scene.render.image_settings,'file_format','FFMPEG')
    enum(scene.render.ffmpeg,'format','MPEG4'); enum(scene.render.ffmpeg,'codec','H264')
    enum(scene.render.ffmpeg,'constant_rate_factor','HIGH')
    scene.render.filepath=str(output/'rlc_animation.mp4')
    bpy.ops.file.pack_all()
    bpy.ops.wm.save_as_mainfile(filepath=str(output/'rlc_animation.blend'))
    return bounds


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--data',type=Path,required=True)
    parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--render',action='store_true')
    parser.add_argument('--width',type=int,default=1920)
    parser.add_argument('--height',type=int,default=1080)
    parser.add_argument('--seconds',type=float,default=26)
    args=parser.parse_args(sys.argv[sys.argv.index('--')+1:])
    args.data=args.data.resolve()
    args.output=args.output.resolve()
    args.output.mkdir(parents=True,exist_ok=True)
    status=args.output/'blender_status.json'
    publish(args.output, 'building')
    try:
        payload=json.loads(args.data.read_text(encoding='utf-8'))
        scene=build(payload,args.output,args.width,args.height,args.seconds)
        bounds=populate(scene,payload,args.output,args.seconds)
        for k,name in [(0,'overview'),(1,'magnetic'),(2,'electric'),(3,'thermal')]:
            publish(args.output, 'previews', completed=k, total=4)
            scene.frame_set(round(bounds[k]+.4*(bounds[k+1]-bounds[k])))
            enum(scene.render.image_settings,'media_type','IMAGE')
            enum(scene.render.image_settings,'file_format','PNG')
            scene.render.filepath=str(args.output/f'{name}.png')
            bpy.ops.render.render(write_still=True)
        if args.render:
            enum(scene.render.image_settings,'media_type','VIDEO')
            enum(scene.render.image_settings,'file_format','FFMPEG')
            scene.render.filepath=str(args.output/'rlc_animation.mp4')
            render_animation(scene, args.output)
        status.write_text(json.dumps({'state':'complete','rendered':args.render,'frames':scene.frame_end,
            'source':str(args.data.resolve()),'source_sha256':hashlib.sha256(args.data.read_bytes()).hexdigest(),
            'style':'presentation','width':args.width,'height':args.height,'seconds':args.seconds},indent=2))
        print('RLC_PRESENTATION_COMPLETE',flush=True)
    except Exception as error:
        status.write_text(json.dumps({'state':'failed','message':str(error)}))
        traceback.print_exc()
        raise


if __name__=='__main__':
    main()

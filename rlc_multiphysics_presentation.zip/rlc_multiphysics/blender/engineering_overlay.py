"""Baked circuit and energy graphics. Geometry is schematic; numbers use run data."""
import math
from rlc_visualize import sample


class EngineeringOverlay:
    def __init__(self, screen, Number, data, parameters, materials):
        white, muted, cyan, amber, mint, panel, rule = materials
        self.data, self.p = data, parameters
        self.screen = screen
        screen.rect('Circuit schematic card',.045,.632,.605,.116,panel)
        screen.text('SERIES CIRCUIT  /  voltage drops follow left-to-right reference',.055,.730,.013,muted,True)
        # Source on left branch, R, L, ideal capacitor and ESR along the top.
        screen.curve('Schematic wiring',[(.075,.709),(.075,.716),(.615,.716),(.615,.653),(.075,.653),(.075,.671)],cyan,.0009)
        screen.curve('Source circle',[(.075+.010*math.cos(j*math.tau/48),.690+.019*math.sin(j*math.tau/48)) for j in range(49)],white,.0009)
        screen.text('+',.071,.691,.014,white)
        screen.text('-',.072,.675,.014,white)
        # Opaque masks prevent wires shorting through schematic component symbols.
        for x in [.19,.32,.45,.56]:
            screen.rect('Symbol mask',x-.022,.701,.044,.027,panel,z=.002)
        def raised_curve(name,points,mat):
            ob=screen.curve(name,points,mat,.001)
            ob.location.z=.003
            return ob
        raised_curve('Resistor symbol',[(.168,.716)]+[(.172+j*.004,.716+(.006 if j%2==0 else -.006)) for j in range(10)]+[(.212,.716)],amber)
        raised_curve('Inductor symbol',[(.298+j*.044/80,.716+.007*abs(math.sin(j/80*math.pi*4))) for j in range(81)],mint)
        for x in [.446,.454]: raised_curve('Capacitor plate symbol',[(x,.705),(x,.727)],cyan)
        raised_curve('Capacitor left lead',[(.428,.716),(.446,.716)],cyan)
        raised_curve('Capacitor right lead',[(.454,.716),(.472,.716)],cyan)
        raised_curve('ESR symbol',[(.538,.710),(.582,.710),(.582,.722),(.538,.722),(.538,.710)],amber)
        self.voltages=[]
        for name,x,mat in [('R',.19,amber),('L',.32,mint),('C ideal',.45,cyan),('ESR',.56,amber)]:
            screen.text(name,x-.014,.684,.013,mat,True)
            self.voltages.append(Number(screen,x-.045,.662,.020,white))
            screen.text('V',x+.026,.665,.012,muted)
        screen.text('Vs',.054,.644,.012,muted)
        self.right=raised_curve('Positive current arrow',[(.122,.699),(.130,.704),(.122,.709)],mint)
        self.left=raised_curve('Negative current arrow',[(.130,.699),(.122,.704),(.130,.709)],mint)
        screen.text('i',.113,.682,.014,mint)
        # Compact bottom strip leaves the physical source visible above it.
        screen.rect('Energy flow strip',.045,.090,.915,.081,panel)
        self.flow=[]
        for text in ['SOURCE -> CIRCUIT','CIRCUIT -> SOURCE','NO SOURCE POWER']:
            self.flow.append(screen.text(text,.055,.153,.013,cyan,True))
        screen.text('Signed source power | stored energy | irreversible heat',.31,.153,.012,muted)
        self.values=[]
        self.bars=[]
        labels=['SOURCE POWER / W','MAGNETIC ENERGY / J','ELECTRIC ENERGY / J','HEAT RATE / W','HEAT GENERATED / J']
        colors=[cyan,mint,cyan,amber,amber]
        self.heat=[0.0]
        losses=[a+b for a,b in zip(data['P_R_W'],data['P_C_W'])]
        for j in range(1,len(losses)):
            self.heat.append(self.heat[-1]+(data['time_s'][j]-data['time_s'][j-1])*(losses[j]+losses[j-1])/2)
        self.heat_data={'time_s':data['time_s'],'heat':self.heat}
        self.scales=[max([abs(v*i) for v,i in zip(data['source_V'],data['i_L_A'])]+[1e-9]),
                     max(data['W_magnetic_J']+[1e-9]),max(data['W_electric_J']+[1e-9]),
                     max(losses+[1e-9]),max(self.heat+[1e-9])]
        for j,(title,mat) in enumerate(zip(labels,colors)):
            x=.055+j*.181
            screen.text(title,x,.130,.012,muted,True)
            self.values.append(Number(screen,x,.108,.024,mat))
            screen.curve('Energy scale',[(x,.098),(x+.15,.098)],rule,.001)
            bar=screen.curve('Relative magnitude',[(x,.098),(x+.15,.098)],mat,.0015)
            # Shift the curve origin to the left endpoint for scaling.
            anchor=(x-.5)*screen.w
            for point in bar.data.splines[0].points: point.co.x-=anchor
            bar.location.x=anchor
            self.bars.append(bar)
        screen.text('Bars: individual full-run scales',.785,.153,.011,muted)

    @staticmethod
    def show(ob, visible, frame):
        ob.hide_render=not visible
        ob.hide_viewport=not visible
        ob.keyframe_insert(data_path='hide_render',frame=frame)
        ob.keyframe_insert(data_path='hide_viewport',frame=frame)

    def update(self, time, frame):
        d=self.data
        i=sample(d,time,'i_L_A'); vs=sample(d,time,'source_V'); vc=sample(d,time,'v_C_V')
        vr=i*sample(d,time,'R_ohm'); ve=i*sample(d,time,'ESR_ohm')
        for display,value in zip(self.voltages,[vr,vs-vr-ve-vc,vc,ve]): display.set(f'{value:+.2f}',frame)
        self.show(self.right,i>1e-8,frame); self.show(self.left,i < -1e-8,frame)
        power=vs*i
        selected=0 if power>1e-8 else 1 if power < -1e-8 else 2
        for j,ob in enumerate(self.flow): self.show(ob,j==selected,frame)
        values=[power,sample(d,time,'W_magnetic_J'),sample(d,time,'W_electric_J'),
                sample(d,time,'P_R_W')+sample(d,time,'P_C_W'),sample(self.heat_data,time,'heat')]
        for display,bar,value,scale in zip(self.values,self.bars,values,self.scales):
            display.set(f'{value:+.3g}',frame)
            bar.scale.x=max(1e-6,min(abs(value)/scale,1))
            bar.keyframe_insert(data_path='scale',frame=frame)

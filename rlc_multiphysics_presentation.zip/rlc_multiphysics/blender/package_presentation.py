"""Package the verified deliverable; exclude caches and exploratory renders."""
import json
import zipfile
from pathlib import Path

root = Path(__file__).resolve().parents[1]
report = json.loads((root/'verification/presentation_report.json').read_text())
assert report['passed']
patterns = ['*.m','*.md','matlab/*.m','matlab/+rlcphysics/*.ssc','blender/*.py',
            'docs/*.md','docs/images/*.png',
            'data/default/rlc_data.*','data/default/rlc_results.mat',
            'data/comparison_example/**/*',
            'verification/report.json','verification/source_report.json',
            'verification/presentation_report.json',
            'verification/engineering/report.json','verification/engineering/overlay_report.json',
            'verification/basic_simulink/cross_backend_report.json',
            'verification/basic_simulink/without_simscape/report.json',
            'media/quick/*.mp4','media/quick/*.png','media/quick/*.blend',
            'media/quick/blender_status.json',
            'media/presentation/*.mp4','media/presentation/*.png',
            'media/presentation/*.blend','media/presentation/*.csv',
            'media/presentation/blender_status.json',
            'matlab/rlc_multiphysics_model.slx','matlab/rlcphysics_lib.slx','matlab/rlc_basic_model.slx']
files = sorted({p for pattern in patterns for p in root.glob(pattern) if p.is_file()})
target = root.parent/'rlc_multiphysics_presentation.zip'
with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED,compresslevel=5) as archive:
    for path in files:
        archive.write(path,Path(root.name)/path.relative_to(root))
with zipfile.ZipFile(target) as archive:
    assert archive.testzip() is None
    assert len(archive.namelist())==len(files)
print(f'Verified {len(files)} files: {target} ({target.stat().st_size:,} bytes)')

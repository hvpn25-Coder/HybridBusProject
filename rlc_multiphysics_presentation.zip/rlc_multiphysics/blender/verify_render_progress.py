"""Short real Blender renders verify progress for both rendering styles."""
import json
import subprocess
import time
from pathlib import Path

root=Path(__file__).resolve().parents[1]
work=root/'verification'/'eta_check'
work.mkdir(parents=True,exist_ok=True)
payload=json.loads((root/'data/default/rlc_data.json').read_text())
payload['metadata']['parameters']['animation_seconds']=1
payload['metadata']['parameters']['fps']=24
data=work/'input.json'
data.write_text(json.dumps(payload))
results={}
for style,script in [('quick','rlc_visualize.py'),('presentation','rlc_cinematic.py')]:
    output=work/style
    output.mkdir(exist_ok=True)
    args=['C:/Tools/Blender/blender.exe','--background','--python-exit-code','1',
          '--python',str(root/'blender'/script),'--','--data',str(data),
          '--output',str(output),'--render','--width','320','--height','180']
    if style=='presentation': args+=['--seconds','1']
    history=[]
    with (output/'blender.log').open('w') as log:
        process=subprocess.Popen(args,stdout=log,stderr=subprocess.STDOUT)
        while process.poll() is None:
            try:
                progress=json.loads((output/'blender_progress.json').read_text())
                if not history or progress!=history[-1]: history.append(progress)
            except (OSError,ValueError): pass
            time.sleep(.05)
    assert process.returncode==0, style
    status=json.loads((output/'blender_status.json').read_text())
    assert status['state']=='complete' and status['rendered']
    frames=[p for p in history if p['phase']=='rendering']
    estimates=[p for p in frames if p.get('eta_seconds') is not None and 3<=p['completed']<24]
    assert estimates, f'No live ETA observed: {style}'
    assert all(p['total']==24 and p['eta_seconds']>=0 for p in estimates)
    assert [p['completed'] for p in frames]==sorted(p['completed'] for p in frames)
    last=json.loads((output/'blender_progress.json').read_text())
    assert last['phase']=='finalizing' and last['completed']==24
    (output/'observed_progress.json').write_text(json.dumps(history,indent=2))
    results[style]={'passed':True,'live_eta_updates_observed':len(estimates),'frames':24}
(work/'report.json').write_text(json.dumps(results,indent=2))
print(json.dumps(results,indent=2))

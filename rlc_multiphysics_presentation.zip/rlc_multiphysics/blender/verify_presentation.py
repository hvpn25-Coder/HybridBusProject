"""Audit presentation timing/data and MP4 metadata using Python's standard library."""
import bisect
import argparse
import csv
import hashlib
import json
import math
import struct
from pathlib import Path

root = Path(__file__).resolve().parents[1]
parser=argparse.ArgumentParser()
parser.add_argument('--folder',type=Path,default=root/'media/presentation')
folder=parser.parse_args().folder.resolve()
data_bytes = (root / 'data/default/rlc_data.json').read_bytes()
data = json.loads(data_bytes)['data']
rows = list(csv.DictReader((folder / 'frame_mapping.csv').open()))
assert len(rows) == 624
errors = {}
for column, field in [('i_A','i_L_A'),('vC_V','v_C_V'),('TR_K','T_R_K'),('TC_K','T_C_K'),('source_V','source_V')]:
    maximum = 0
    for n, row in enumerate(rows):
        assert int(row['frame']) == n+1
        assert abs(float(row['video_time_s'])-n/24) < 1e-10
        t = float(row['physical_time_s'])
        ts = data['time_s']
        assert ts[0] <= t <= ts[-1]
        j = min(max(bisect.bisect_right(ts,t)-1,0),len(ts)-2)
        u = (t-ts[j])/(ts[j+1]-ts[j])
        expected = data[field][j]*(1-u)+data[field][j+1]*u
        maximum = max(maximum,abs(expected-float(row[column])))
    assert maximum < 1e-9, (column,maximum)
    errors[column] = maximum

def boxes(blob, start=0, end=None):
    end = len(blob) if end is None else end
    while start+8 <= end:
        size, kind = struct.unpack_from('>I4s',blob,start)
        header = 8
        if size == 1:
            size = struct.unpack_from('>Q',blob,start+8)[0]; header=16
        if size == 0: size=end-start
        assert size >= header and start+size <= end
        yield kind, blob[start+header:start+size]
        start += size

status = json.loads((folder/'blender_status.json').read_text())
assert status['state']=='complete' and status['rendered']
assert status['source_sha256']==hashlib.sha256(data_bytes).hexdigest()
video = (folder/'rlc_animation.mp4').read_bytes()
moov = next(b for k,b in boxes(video) if k==b'moov')
mvhd = next(b for k,b in boxes(moov) if k==b'mvhd')
offset = 20 if mvhd[0] == 1 else 12
scale = struct.unpack_from('>I',mvhd,offset)[0]
duration = struct.unpack_from('>Q' if mvhd[0]==1 else '>I',mvhd,offset+4)[0]/scale
tracks=[]
sample_counts=[]
for kind,track in boxes(moov):
    if kind != b'trak': continue
    header = next(b for k,b in boxes(track) if k==b'tkhd')
    width,height=struct.unpack_from('>II',header,len(header)-8)
    tracks.append([width/65536,height/65536])
    if width and height:
        media=next(b for k,b in boxes(track) if k==b'mdia')
        info=next(b for k,b in boxes(media) if k==b'minf')
        table=next(b for k,b in boxes(info) if k==b'stbl')
        sizes=next(b for k,b in boxes(table) if k==b'stsz')
        sample_counts.append(struct.unpack_from('>I',sizes,8)[0])
assert [1920,1080] in tracks
assert sample_counts==[624], sample_counts
assert math.isclose(duration,26,abs_tol=.05)
report={'passed':True,'frames_checked':len(rows),'maximum_sample_errors':errors,
        'video_seconds':duration,'track_dimensions':tracks,'encoded_frame_counts':sample_counts,'bytes':len(video),
        'source_sha256':status['source_sha256']}
(root/'verification/presentation_report.json').write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2))
